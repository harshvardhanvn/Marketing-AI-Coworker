"""
Campaign Analyst agent.

The numbers (CTR, CPC, conversion rate, CPA, ROAS) are computed in Python by
services.csv_metrics. Sarvam is only asked to *interpret* those numbers and
suggest optimisations - it never produces the metrics themselves.
"""
from __future__ import annotations

from typing import Any, Dict

from services import csv_metrics
from sarvam_client import get_client

SYSTEM = (
    "You are a performance-marketing analyst. You are given pre-computed "
    "campaign metrics that are authoritative. Interpret them: call out the "
    "best and worst campaigns, likely causes, and 3-5 concrete optimisation "
    "actions. Never recompute or contradict the supplied numbers. Plain text."
)


def _fmt(v):
    return "n/a" if v is None else v


def _demo_summary(data: Dict[str, Any]) -> str:
    s = data["summary"]
    h = data["highlights"]
    lines = [
        "Campaign performance interpretation",
        "",
        f"Overall CTR: {_fmt(s['ctr_pct'])}%  |  CPC: {_fmt(s['cpc'])}  |  "
        f"Conv. rate: {_fmt(s['conversion_rate_pct'])}%  |  CPA: {_fmt(s['cpa'])}  |  "
        f"ROAS: {_fmt(s['roas'])}",
        "",
        f"Best ROAS campaign: {h['best_roas_campaign']} (ROAS {_fmt(h['best_roas_value'])})",
        f"Worst CPA campaign: {h['worst_cpa_campaign']} (CPA {_fmt(h['worst_cpa_value'])})",
        "",
        "Suggested actions:",
        "  1. Shift budget toward the highest-ROAS campaign.",
        "  2. Pause or rework the highest-CPA campaign.",
        "  3. Test new creative on the lowest-CTR campaigns.",
        "  4. Tighten audience targeting where conversion rate lags.",
    ]
    return "\n".join(lines)


def run(csv_content: bytes | str, business: Dict[str, Any] | None = None) -> Dict[str, Any]:
    data = csv_metrics.parse_and_analyse(csv_content)

    user_prompt = (
        f"Business context: {(business or {}).get('description', 'not provided')}\n"
        f"Computed metrics summary: {data['summary']}\n"
        f"Totals: {data['totals']}\n"
        f"Per-campaign: {data['rows']}\n"
        f"Highlights: {data['highlights']}\n\n"
        "Interpret these results and recommend optimisations."
    )

    llm = get_client().chat(
        system=SYSTEM,
        user=user_prompt,
        temperature=0.3,
        max_tokens=1200,
        demo_text=_demo_summary(data),
    )

    s = data["summary"]
    recommendations = []
    if s.get("roas") is not None and s["roas"] < 2:
        recommendations.append({
            "agent": "Campaign Analyst",
            "title": f"Overall ROAS is low ({s['roas']})",
            "detail": "ROAS below 2x suggests spend is not paying back. Reallocate to the best-ROAS campaign and cut the worst CPA line.",
            "priority": "high",
        })
    if data["highlights"]["worst_cpa_campaign"]:
        recommendations.append({
            "agent": "Campaign Analyst",
            "title": f"Review high-CPA campaign '{data['highlights']['worst_cpa_campaign']}'",
            "detail": f"CPA of {data['highlights']['worst_cpa_value']} is the worst in the set. Audit targeting, landing page and offer.",
            "priority": "medium",
        })
    recommendations.append({
        "agent": "Campaign Analyst",
        "title": "Scale the best-ROAS campaign",
        "detail": f"'{data['highlights']['best_roas_campaign']}' has the strongest ROAS ({data['highlights']['best_roas_value']}); increase budget in small increments and monitor CPA.",
        "priority": "medium",
    })

    return {
        "agent": "Campaign Analyst",
        "metrics": data,
        "llm": llm.to_dict(),
        "recommendations": recommendations,
    }
