"""
Content Creator agent.

Generates editable marketing assets: ad copy, landing-page copy, blog
outlines, social posts and email copy. Output is always returned as editable
text (and stored so it can be retrieved/edited later).
"""
from __future__ import annotations

from typing import Any, Dict

from sarvam_client import get_client

ASSET_TYPES = {
    "ad_copy": "Short paid-ad copy: 3 headline variants, 2 primary texts, and a CTA.",
    "landing_page": "Landing-page copy: hero headline, subhead, 3 benefit blocks, social proof line, CTA.",
    "blog_outline": "SEO blog outline: title options, H2/H3 structure, and target keywords per section.",
    "social_post": "Three social posts (LinkedIn / Instagram / X) with a hook and CTA.",
    "email": "Promotional email: subject lines, preview text, body, and CTA.",
}

SYSTEM = (
    "You are a conversion copywriter for a D2C brand. Write clear, specific, "
    "on-brand marketing copy. No hype, no fabricated statistics or testimonials. "
    "Return the copy directly, formatted with short labelled sections so it is "
    "easy to edit. Plain text."
)


def _demo_summary(asset_type: str, topic: str, business: Dict[str, Any] | None) -> str:
    brand = (business or {}).get("name", "the brand")
    if asset_type == "ad_copy":
        return (
            f"Ad copy for {brand} - {topic}\n\n"
            f"Headline A: {topic} that actually works\n"
            f"Headline B: Try {topic} - loved by health-conscious homes\n"
            f"Headline C: {topic}, minus the compromises\n\n"
            f"Primary text 1: Discover {topic} from {brand}. Clean ingredients, honest labels, "
            "delivered to your door.\n"
            f"Primary text 2: Switching to {topic} shouldn't be complicated. {brand} makes it simple.\n\n"
            "CTA: Shop now"
        )
    if asset_type == "landing_page":
        return (
            f"Landing page - {brand} - {topic}\n\n"
            f"Hero: {topic}, done right\n"
            f"Subhead: {brand} brings you {topic} with clean sourcing and transparent labels.\n\n"
            "Benefits:\n"
            "  1. Sourced clean, tested for purity\n"
            "  2. Delivered fast across India\n"
            "  3. Loved by health-conscious households\n\n"
            "CTA: Start your order"
        )
    if asset_type == "blog_outline":
        return (
            f"Blog outline - {topic}\n\n"
            f"Title options: The honest guide to {topic}; {topic} explained;\n\n"
            "H2: What is " + topic + "?\n"
            "H2: Why it matters\n"
            "  H3: Common mistakes\n"
            "H2: How to choose\n"
            "H2: FAQ\n\n"
            f"Target keyword: {topic}"
        )
    if asset_type == "social_post":
        return (
            f"Social posts - {brand} - {topic}\n\n"
            f"LinkedIn: We built {brand} around one idea: {topic} without the compromises.\n"
            f"Instagram: {topic} -> simple, clean, delivered. Tap to shop.\n"
            f"X: {topic}, minus the fuss. Now shipping across India."
        )
    return (
        f"Email - {brand} - {topic}\n\n"
        f"Subject: {topic}, the way it should be\n"
        f"Preview: Clean sourcing, honest labels, delivered.\n\n"
        f"Body: Hi there, meet {topic} from {brand}...\n\nCTA: Shop the range"
    )


def run(asset_type: str, topic: str, business: Dict[str, Any] | None = None,
        tone: str = "confident and friendly", extra: str = "") -> Dict[str, Any]:
    asset_type = (asset_type or "").strip()
    if asset_type not in ASSET_TYPES:
        raise ValueError(f"Unknown asset type '{asset_type}'. Valid: {', '.join(ASSET_TYPES)}")
    topic = (topic or "").strip()
    if not topic:
        raise ValueError("A topic is required to generate content.")

    user_prompt = (
        f"Brand: {(business or {}).get('name', 'the brand')}\n"
        f"Business context: {(business or {}).get('description', 'not provided')}\n"
        f"Asset type: {asset_type} - {ASSET_TYPES[asset_type]}\n"
        f"Topic: {topic}\n"
        f"Tone: {tone}\n"
        f"Extra instructions: {extra or 'none'}\n\n"
        "Write the asset."
    )

    llm = get_client().chat(
        system=SYSTEM,
        user=user_prompt,
        temperature=0.7,
        max_tokens=1500,
        demo_text=_demo_summary(asset_type, topic, business),
    )

    return {
        "agent": "Content Creator",
        "asset_type": asset_type,
        "topic": topic,
        "tone": tone,
        "body": llm.text,
        "llm": llm.to_dict(),
        "recommendations": [],
    }
