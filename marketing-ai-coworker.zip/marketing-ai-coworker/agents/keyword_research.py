"""
Keyword Research agent.

Generates intent-based keyword clusters and content opportunities.

IMPORTANT: this agent does NOT produce search-volume, CPC or difficulty
numbers. We have no keyword-volume data source, so inventing metrics would be
fabrication. Output is clusters + intent + content ideas only, and the result
carries an explicit note to that effect.
"""
from __future__ import annotations

from typing import Any, Dict, List

from sarvam_client import get_client

SYSTEM = (
    "You are an SEO keyword strategist. Given a topic and business context, "
    "produce intent-based keyword clusters (informational, commercial, "
    "transactional, navigational) and matching content opportunities. "
    "Do NOT include or invent search-volume, CPC, or difficulty numbers - you "
    "do not have that data. Plain text, clearly grouped by intent."
)

INTENT_TEMPLATES = {
    "informational": ["what is {s}", "how to choose {s}", "{s} benefits", "{s} guide", "why {s} matters"],
    "commercial": ["best {s}", "{s} comparison", "top {s} brands", "{s} reviews", "affordable {s}"],
    "transactional": ["buy {s} online", "{s} price", "{s} near me", "{s} discount", "order {s}"],
    "navigational": ["{s} official site", "{s} brand", "{s} login", "{s} customer care"],
}

CONTENT_IDEAS = {
    "informational": "Pillar blog post / FAQ hub answering the core question in depth.",
    "commercial": "Comparison landing page or buyer's guide with a decision table.",
    "transactional": "Conversion-optimised product/category page with clear CTAs.",
    "navigational": "Brand page and support/knowledge-base content.",
}


def _heuristic_clusters(seed: str) -> List[Dict[str, Any]]:
    seed = seed.strip().lower()
    clusters = []
    for intent, templates in INTENT_TEMPLATES.items():
        clusters.append({
            "intent": intent,
            "keywords": [t.format(s=seed) for t in templates],
            "content_opportunity": CONTENT_IDEAS[intent],
        })
    return clusters


def _demo_summary(seed: str, clusters: List[Dict[str, Any]]) -> str:
    lines = [f"Keyword clusters for '{seed}' (intent-based, no volume data)", ""]
    for c in clusters:
        lines.append(f"{c['intent'].upper()}")
        lines.append("  Keywords: " + ", ".join(c["keywords"]))
        lines.append(f"  Content: {c['content_opportunity']}")
        lines.append("")
    return "\n".join(lines).strip()


def run(topic: str, business: Dict[str, Any] | None = None, seed_keywords: List[str] | None = None) -> Dict[str, Any]:
    topic = (topic or "").strip()
    if not topic:
        raise ValueError("A topic or seed keyword is required.")

    seeds = [topic] + [s.strip() for s in (seed_keywords or []) if s.strip()]
    clusters = _heuristic_clusters(topic)

    user_prompt = (
        f"Business context: {(business or {}).get('description', 'not provided')}\n"
        f"Primary topic: {topic}\n"
        f"Seed keywords: {seeds}\n\n"
        "Produce intent-based keyword clusters and content opportunities. "
        "Do not include search-volume or CPC figures."
    )

    llm = get_client().chat(
        system=SYSTEM,
        user=user_prompt,
        temperature=0.4,
        max_tokens=1200,
        demo_text=_demo_summary(topic, clusters),
    )

    recommendations = [
        {
            "agent": "Keyword Research",
            "title": f"Build {c['intent']} content for '{topic}'",
            "detail": c["content_opportunity"],
            "priority": "medium" if c["intent"] in ("informational", "commercial") else "low",
        }
        for c in clusters
    ]

    return {
        "agent": "Keyword Research",
        "topic": topic,
        "seed_keywords": seeds,
        "clusters": clusters,
        "llm": llm.to_dict(),
        "note": "Keyword clusters are intent-based only. No search-volume, CPC or "
                "difficulty metrics are produced because no keyword-data source is configured.",
        "recommendations": recommendations,
    }
