"""
Marketing Manager - the orchestrator.

Runs the specialist agents it has inputs for, aggregates their findings, and
asks Sarvam to synthesise a single prioritised growth plan. Each specialist is
run inside a guard so one failure never sinks the whole run; the plan records
which agents ran and which failed.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from agents import campaign_analyst, content_creator, keyword_research, seo_analyst
from sarvam_client import get_client

PRIORITY_ORDER = {"high": 0, "medium": 1, "low": 2}

SYSTEM = (
    "You are a Head of Growth. You are given findings from specialist agents "
    "(SEO, paid-campaign performance, keyword research). Synthesise ONE "
    "prioritised growth plan: a short executive summary, then a ranked list of "
    "actions each tagged HIGH/MEDIUM/LOW with the expected impact. Do not "
    "invent data that is not in the findings. Plain text."
)


def _run_safe(name, fn, *args, **kwargs) -> Dict[str, Any]:
    try:
        result = fn(*args, **kwargs)
        return {"agent": name, "ok": True, "result": result, "error": None}
    except Exception as exc:
        return {"agent": name, "ok": False, "result": None, "error": f"{type(exc).__name__}: {exc}"}


def _demo_plan(findings: Dict[str, Any], recommendations: List[Dict[str, Any]]) -> str:
    lines = ["Prioritised growth plan", ""]
    if "seo" in findings:
        lines.append(f"- SEO score for {findings['seo']['url']}: {findings['seo']['seo_score']}/100")
    if "campaign" in findings:
        s = findings["campaign"]["metrics"]["summary"]
        lines.append(f"- Campaign ROAS: {s.get('roas')}  |  CPA: {s.get('cpa')}  |  CTR: {s.get('ctr_pct')}%")
    if "keywords" in findings:
        lines.append(f"- Keyword clusters generated: {len(findings['keywords']['clusters'])}")
    lines.append("")
    lines.append("Ranked actions:")
    for i, r in enumerate(recommendations[:8], 1):
        lines.append(f"  {i}. [{r['priority'].upper()}] {r['title']} - {r['detail']}")
    return "\n".join(lines).strip()


def run(
    business: Dict[str, Any] | None = None,
    url: Optional[str] = None,
    csv_content: Optional[bytes | str] = None,
    topic: Optional[str] = None,
    generate_content: bool = False,
) -> Dict[str, Any]:
    findings: Dict[str, Any] = {}
    runs: List[Dict[str, Any]] = []

    if url:
        run_res = _run_safe("SEO Analyst", seo_analyst.run, url, business)
        runs.append(run_res)
        if run_res["ok"]:
            findings["seo"] = run_res["result"]

    if csv_content:
        run_res = _run_safe("Campaign Analyst", campaign_analyst.run, csv_content, business)
        runs.append(run_res)
        if run_res["ok"]:
            findings["campaign"] = run_res["result"]

    if topic:
        run_res = _run_safe("Keyword Research", keyword_research.run, topic, business)
        runs.append(run_res)
        if run_res["ok"]:
            findings["keywords"] = run_res["result"]

        if generate_content:
            run_res = _run_safe("Content Creator", content_creator.run, "ad_copy", topic, business)
            runs.append(run_res)
            if run_res["ok"]:
                findings["content"] = run_res["result"]

    if not findings:
        raise ValueError("Nothing to orchestrate: provide at least a URL, a CSV, or a topic.")

    # Aggregate + dedupe recommendations.
    recs: List[Dict[str, Any]] = []
    seen = set()
    for key in ("seo", "campaign", "keywords", "content"):
        if key in findings:
            for r in findings[key].get("recommendations", []):
                sig = (r["title"].lower(), r["detail"][:60].lower())
                if sig in seen:
                    continue
                seen.add(sig)
                recs.append(r)
    recs.sort(key=lambda r: PRIORITY_ORDER.get(r.get("priority", "low"), 2))

    agents_ran = [r["agent"] for r in runs if r["ok"]]
    agents_failed = [{"agent": r["agent"], "error": r["error"]} for r in runs if not r["ok"]]

    user_prompt = (
        f"Business: {(business or {}).get('name')} - {(business or {}).get('description', '')}\n\n"
        f"Findings summary: {_condense(findings)}\n\n"
        f"Aggregated recommendations: {recs}\n\n"
        "Write the prioritised growth plan."
    )

    llm = get_client().chat(
        system=SYSTEM,
        user=user_prompt,
        temperature=0.3,
        max_tokens=1500,
        demo_text=_demo_plan(findings, recs),
    )

    return {
        "agent": "Marketing Manager",
        "agents_ran": agents_ran,
        "agents_failed": agents_failed,
        "findings": findings,
        "recommendations": recs,
        "growth_plan": llm.text,
        "llm": llm.to_dict(),
        "demo": llm.demo,
    }


def _condense(findings: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if "seo" in findings:
        f = findings["seo"]
        out["seo"] = {"url": f["url"], "score": f["seo_score"], "issue_counts": f["issue_counts"]}
    if "campaign" in findings:
        out["campaign"] = {
            "summary": findings["campaign"]["metrics"]["summary"],
            "highlights": findings["campaign"]["metrics"]["highlights"],
        }
    if "keywords" in findings:
        out["keywords"] = {"topic": findings["keywords"]["topic"],
                           "clusters": [c["intent"] for c in findings["keywords"]["clusters"]]}
    if "content" in findings:
        out["content"] = {"asset_type": findings["content"]["asset_type"]}
    return out
