"""
SEO Analyst agent.

Fetches a real public page, extracts on-page facts, and asks Sarvam to turn
the machine-detected issues into prioritised, human-readable recommendations.
The *detection* is deterministic (services.website); Sarvam only writes the
advice, so a demo-mode run still produces correct findings.
"""
from __future__ import annotations

from typing import Any, Dict, List

from services import website
from sarvam_client import get_client

SYSTEM = (
    "You are a senior technical SEO consultant. You are given verified on-page "
    "findings for a single web page. Write concise, specific, prioritised "
    "recommendations. Do not invent facts that are not in the findings. "
    "Return plain text, grouped as HIGH / MEDIUM / LOW priorities."
)


def _demo_summary(url: str, facts: Dict[str, Any], issues: List[Dict[str, str]]) -> str:
    lines = [f"On-page SEO review for {url}", ""]
    for sev in ("high", "medium", "low"):
        bucket = [i for i in issues if i["severity"] == sev]
        if not bucket:
            continue
        lines.append(f"{sev.upper()} priority")
        for i in bucket:
            lines.append(f"  - [{i['area']}] {i['issue']} -> {i['fix']}")
        lines.append("")
    lines.append(
        f"Page stats: title {facts['title_length']} chars, "
        f"{facts['word_count']} words, {facts['images_total']} images, "
        f"H1 count {facts['h1_count']}."
    )
    return "\n".join(lines).strip()


def run(url: str, business: Dict[str, Any] | None = None) -> Dict[str, Any]:
    analysis = website.analyse_url(url)
    facts = analysis["facts"]
    issues = analysis["issues"]

    actionable = [i for i in issues if i["severity"] in ("high", "medium", "low")]
    user_prompt = (
        f"Business context: {(business or {}).get('description', 'not provided')}\n"
        f"URL: {analysis['final_url']}\n"
        f"Facts: {facts}\n"
        f"Detected issues: {actionable}\n\n"
        "Write prioritised SEO recommendations."
    )

    llm = get_client().chat(
        system=SYSTEM,
        user=user_prompt,
        temperature=0.2,
        max_tokens=1200,
        demo_text=_demo_summary(analysis["final_url"], facts, issues),
    )

    recommendations = [
        {
            "agent": "SEO Analyst",
            "title": f"{i['severity'].upper()}: {i['area']} - {i['issue']}",
            "detail": i["fix"],
            "priority": {"high": "high", "medium": "medium", "low": "low"}.get(i["severity"], "low"),
        }
        for i in actionable
    ]

    return {
        "agent": "SEO Analyst",
        "url": analysis["final_url"],
        "seo_score": analysis["seo_score"],
        "issue_counts": analysis["issue_counts"],
        "facts": facts,
        "issues": issues,
        "llm": llm.to_dict(),
        "recommendations": recommendations,
    }
