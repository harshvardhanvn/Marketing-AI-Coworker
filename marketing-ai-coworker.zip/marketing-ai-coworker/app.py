"""
Marketing AI Coworker - Flask application.

Exposes the specialist agents and the Marketing Manager orchestrator over a
JSON API, persists results, and serves the dashboard. Every endpoint validates
input and returns structured JSON errors.
"""
from __future__ import annotations

import csv
import io
import os

from flask import Flask, jsonify, request, render_template, send_file, Response

import config
import db
from agents import (
    campaign_analyst,
    content_creator,
    keyword_research,
    marketing_manager,
    seo_analyst,
)
from services import csv_metrics, website

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = config.MAX_UPLOAD_BYTES
app.config["SECRET_KEY"] = config.SECRET_KEY

db.init_db()


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def ok(payload: dict, status: int = 200):
    return jsonify({"ok": True, **payload}), status


def err(message: str, status: int = 400, **extra):
    return jsonify({"ok": False, "error": message, **extra}), status


def _business():
    return db.get_business() or {}


# --------------------------------------------------------------------------
# Pages + meta
# --------------------------------------------------------------------------
@app.get("/")
def index():
    return render_template("index.html", status=config.status(), business=_business())


@app.get("/api/health")
def health():
    from sarvam_client import get_client
    return ok({
        "status": "running",
        "app": "Marketing AI Coworker",
        "config": config.status(),
        "sarvam": get_client().health_check(),
        "counts": {
            "recommendations": len(db.list_recommendations()),
            "snapshots": len(db.list_snapshots()),
            "content_assets": len(db.list_content_assets()),
            "analyses": len(db.list_analyses()),
            "experiments": len(db.list_experiments()),
        },
    })


@app.get("/api/business")
def business():
    return ok({"business": _business()})


# --------------------------------------------------------------------------
# 1. SEO Analyst
# --------------------------------------------------------------------------
@app.post("/api/seo/analyze")
def seo_analyze():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    if not url:
        return err("A 'url' field is required.")
    try:
        result = seo_analyst.run(url, _business())
    except website.FetchError as exc:
        return err(str(exc), 422)
    except Exception as exc:
        return err(f"SEO analysis failed: {type(exc).__name__}: {exc}", 500)

    bid = _business().get("id")
    db.add_analysis(bid, "seo", result, {"url": url}, demo=result["llm"]["demo"])
    db.add_recommendations(bid, result["recommendations"])
    return ok({"result": result})


# --------------------------------------------------------------------------
# 2. Campaign Analyst
# --------------------------------------------------------------------------
def _read_upload_or_sample():
    """Return (content_bytes, source_filename) or raise CSVValidationError."""
    if "file" in request.files and request.files["file"].filename:
        f = request.files["file"]
        ext = os.path.splitext(f.filename)[1].lower()
        if ext not in config.ALLOWED_UPLOAD_EXT:
            raise csv_metrics.CSVValidationError(
                f"Unsupported file type '{ext}'. Please upload a .csv file."
            )
        return f.read(), f.filename
    data = request.get_json(silent=True) or {}
    if data.get("use_sample"):
        with open(config.SAMPLE_CSV_PATH, "rb") as fh:
            return fh.read(), os.path.basename(config.SAMPLE_CSV_PATH)
    raise csv_metrics.CSVValidationError("Upload a CSV file or set 'use_sample': true.")


@app.post("/api/campaign/analyze")
def campaign_analyze():
    try:
        content, filename = _read_upload_or_sample()
    except csv_metrics.CSVValidationError as exc:
        return err(str(exc), 422)

    try:
        result = campaign_analyst.run(content, _business())
    except csv_metrics.CSVValidationError as exc:
        return err(str(exc), 422)
    except Exception as exc:
        return err(f"Campaign analysis failed: {type(exc).__name__}: {exc}", 500)

    bid = _business().get("id")
    db.add_analysis(bid, "campaign", result, {"filename": filename}, demo=result["llm"]["demo"])
    db.add_recommendations(bid, result["recommendations"])

    # Persist a snapshot so it can be compared later.
    snap_name = (request.form.get("snapshot_name")
                 or (request.get_json(silent=True) or {}).get("snapshot_name")
                 or filename)
    snap_id = db.add_snapshot(bid, snap_name, result["metrics"], source_filename=filename)

    return ok({"result": result, "snapshot_id": snap_id})


# --------------------------------------------------------------------------
# 3. Keyword Research
# --------------------------------------------------------------------------
@app.post("/api/keywords/research")
def keywords_research():
    data = request.get_json(silent=True) or {}
    topic = (data.get("topic") or "").strip()
    if not topic:
        return err("A 'topic' field is required.")
    try:
        result = keyword_research.run(topic, _business(), data.get("seed_keywords"))
    except ValueError as exc:
        return err(str(exc), 422)
    except Exception as exc:
        return err(f"Keyword research failed: {type(exc).__name__}: {exc}", 500)

    bid = _business().get("id")
    db.add_analysis(bid, "keywords", result, {"topic": topic}, demo=result["llm"]["demo"])
    db.add_recommendations(bid, result["recommendations"])
    return ok({"result": result})


# --------------------------------------------------------------------------
# 4. Content Creator
# --------------------------------------------------------------------------
@app.post("/api/content/generate")
def content_generate():
    data = request.get_json(silent=True) or {}
    asset_type = (data.get("asset_type") or "").strip()
    topic = (data.get("topic") or "").strip()
    if not asset_type:
        return err("An 'asset_type' field is required.")
    if not topic:
        return err("A 'topic' field is required.")
    try:
        result = content_creator.run(
            asset_type, topic, _business(),
            tone=data.get("tone", "confident and friendly"),
            extra=data.get("extra", ""),
        )
    except ValueError as exc:
        return err(str(exc), 422)
    except Exception as exc:
        return err(f"Content generation failed: {type(exc).__name__}: {exc}", 500)

    bid = _business().get("id")
    asset_id = db.add_content_asset(bid, asset_type, topic, result["body"], demo=result["llm"]["demo"])
    return ok({"result": result, "asset_id": asset_id})


@app.get("/api/content")
def content_list():
    return ok({"assets": db.list_content_assets(_business().get("id")),
               "asset_types": list(content_creator.ASSET_TYPES.keys())})


# --------------------------------------------------------------------------
# 5. Marketing Manager
# --------------------------------------------------------------------------
@app.post("/api/manager/run")
def manager_run():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip() or None
    topic = (data.get("topic") or "").strip() or None
    csv_content = None

    if data.get("use_sample_csv"):
        with open(config.SAMPLE_CSV_PATH, "rb") as fh:
            csv_content = fh.read()
    elif data.get("csv_text"):
        csv_content = data["csv_text"]

    if not any([url, topic, csv_content]):
        return err("Provide at least one of: url, topic, use_sample_csv.")

    try:
        result = marketing_manager.run(
            business=_business(), url=url, csv_content=csv_content, topic=topic,
            generate_content=bool(data.get("generate_content")),
        )
    except ValueError as exc:
        return err(str(exc), 422)
    except Exception as exc:
        return err(f"Orchestration failed: {type(exc).__name__}: {exc}", 500)

    bid = _business().get("id")
    db.add_analysis(bid, "manager", result, {"url": url, "topic": topic}, demo=result["demo"])
    db.add_recommendations(bid, result["recommendations"])
    if "content" in result["findings"]:
        c = result["findings"]["content"]
        db.add_content_asset(bid, c["asset_type"], c["topic"], c["body"], demo=c["llm"]["demo"])
    return ok({"result": result})


# --------------------------------------------------------------------------
# 6. Recommendations
# --------------------------------------------------------------------------
@app.get("/api/recommendations")
def recommendations_list():
    status = request.args.get("status")
    return ok({"recommendations": db.list_recommendations(_business().get("id"), status)})


@app.patch("/api/recommendations/<int:rec_id>")
def recommendations_update(rec_id):
    data = request.get_json(silent=True) or {}
    status = (data.get("status") or "").strip()
    if status not in ("open", "in_progress", "done", "dismissed"):
        return err("status must be one of: open, in_progress, done, dismissed.")
    if not db.update_recommendation_status(rec_id, status):
        return err(f"Recommendation {rec_id} not found.", 404)
    return ok({"updated": rec_id, "status": status})


# --------------------------------------------------------------------------
# 7. Snapshots + comparison
# --------------------------------------------------------------------------
@app.get("/api/snapshots")
def snapshots_list():
    snaps = db.list_snapshots(_business().get("id"))
    # Don't ship full row-level metrics in the list view; keep it light.
    light = [{
        "id": s["id"], "name": s["name"], "source_filename": s["source_filename"],
        "created_at": s["created_at"], "summary": s["metrics"].get("summary", {}),
        "row_count": s["metrics"].get("row_count"),
    } for s in snaps]
    return ok({"snapshots": light})


@app.get("/api/snapshots/<int:snap_id>")
def snapshot_get(snap_id):
    s = db.get_snapshot(snap_id)
    if not s:
        return err(f"Snapshot {snap_id} not found.", 404)
    return ok({"snapshot": s})


@app.post("/api/snapshots/compare")
def snapshots_compare():
    data = request.get_json(silent=True) or {}
    older_id, newer_id = data.get("older_id"), data.get("newer_id")
    if not older_id or not newer_id:
        return err("Both 'older_id' and 'newer_id' are required.")
    older = db.get_snapshot(int(older_id))
    newer = db.get_snapshot(int(newer_id))
    if not older or not newer:
        return err("One or both snapshots were not found.", 404)
    comparison = csv_metrics.compare_snapshots(older["metrics"], newer["metrics"])
    return ok({
        "older": {"id": older["id"], "name": older["name"], "created_at": older["created_at"]},
        "newer": {"id": newer["id"], "name": newer["name"], "created_at": newer["created_at"]},
        "comparison": comparison,
    })


# --------------------------------------------------------------------------
# 8. Experiments
# --------------------------------------------------------------------------
@app.post("/api/experiments")
def experiments_create():
    data = request.get_json(silent=True) or {}
    title = (data.get("title") or "").strip()
    if not title:
        return err("A 'title' field is required.")
    exp_id = db.add_experiment(
        _business().get("id"), title,
        (data.get("hypothesis") or "").strip(),
        (data.get("primary_metric") or "").strip(),
        status=data.get("status", "planned"),
    )
    return ok({"experiment_id": exp_id})


@app.get("/api/experiments")
def experiments_list():
    return ok({"experiments": db.list_experiments(_business().get("id"))})


# --------------------------------------------------------------------------
# 9. History
# --------------------------------------------------------------------------
@app.get("/api/history")
def history():
    atype = request.args.get("type")
    rows = db.list_analyses(_business().get("id"), atype, limit=int(request.args.get("limit", 50)))
    light = [{
        "id": r["id"], "analysis_type": r["analysis_type"], "created_at": r["created_at"],
        "demo": bool(r["demo"]), "input": r["input"],
    } for r in rows]
    return ok({"history": light})


# --------------------------------------------------------------------------
# 10. Exports + sample download
# --------------------------------------------------------------------------
@app.get("/api/export/recommendations.csv")
def export_recommendations():
    recs = db.list_recommendations(_business().get("id"))
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "agent", "priority", "status", "title", "detail", "created_at"])
    for r in recs:
        w.writerow([r["id"], r["agent"], r["priority"], r["status"], r["title"], r["detail"], r["created_at"]])
    return _csv_response(buf.getvalue(), "recommendations.csv")


@app.get("/api/export/snapshots/<int:snap_id>.csv")
def export_snapshot(snap_id):
    s = db.get_snapshot(snap_id)
    if not s:
        return err(f"Snapshot {snap_id} not found.", 404)
    rows = s["metrics"]["rows"]
    buf = io.StringIO()
    w = csv.writer(buf)
    cols = ["campaign", "impressions", "clicks", "spend", "conversions", "revenue",
            "ctr_pct", "cpc", "conversion_rate_pct", "cpa", "roas"]
    w.writerow(cols)
    for r in rows:
        w.writerow([r.get(c) for c in cols])
    return _csv_response(buf.getvalue(), f"snapshot_{snap_id}.csv")


@app.get("/api/sample/campaign.csv")
def sample_csv():
    v = request.args.get("version", "1")
    path = config.SAMPLE_CSV_PATH if v == "1" else config.BASE_DIR / "sample_data" / "sample_campaign_v2.csv"
    return send_file(path, mimetype="text/csv", as_attachment=True, download_name=os.path.basename(path))


def _csv_response(text: str, filename: str) -> Response:
    return Response(
        text, mimetype="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# --------------------------------------------------------------------------
# Error handlers
# --------------------------------------------------------------------------
@app.errorhandler(413)
def too_large(_):
    return err(f"File too large. Max upload is {config.MAX_UPLOAD_BYTES // (1024*1024)} MB.", 413)


@app.errorhandler(404)
def not_found(_):
    return err("Endpoint not found.", 404)


@app.errorhandler(500)
def server_error(_):
    return err("Internal server error.", 500)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=bool(os.environ.get("MAC_DEBUG")))
