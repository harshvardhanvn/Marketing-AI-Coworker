"""
Central configuration for the Marketing AI Coworker.

All secrets are read from environment variables. Nothing is hard-coded.
If SARVAM_API_KEY is missing the app runs in DEMO MODE: the full workflow
still executes, but LLM calls return clearly-labelled canned output instead
of a live API response. Demo responses are always tagged so they can never
be mistaken for real model output.
"""
from __future__ import annotations

import os
from pathlib import Path

try:  # optional convenience: load a local .env if python-dotenv is present
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent / ".env")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent

# --- Paths -----------------------------------------------------------------
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = os.environ.get("MAC_DB_PATH", str(DATA_DIR / "marketing_ai_coworker.db"))
SAMPLE_CSV_PATH = BASE_DIR / "sample_data" / "sample_campaign.csv"

# --- Sarvam AI -------------------------------------------------------------
SARVAM_API_KEY = os.environ.get("SARVAM_API_KEY", "").strip()
SARVAM_MODEL = os.environ.get("SARVAM_MODEL", "sarvam-105b")
SARVAM_TIMEOUT = int(os.environ.get("SARVAM_TIMEOUT", "60"))

# --- Behaviour -------------------------------------------------------------
# Hard cap on outbound fetches for the SEO agent (seconds).
HTTP_TIMEOUT = int(os.environ.get("MAC_HTTP_TIMEOUT", "15"))
# Max bytes we will read from a fetched page, to keep memory bounded.
HTTP_MAX_BYTES = int(os.environ.get("MAC_HTTP_MAX_BYTES", str(2_000_000)))
USER_AGENT = os.environ.get(
    "MAC_USER_AGENT",
    "MarketingAICoworkerBot/1.0 (+https://example.com/bot; contact: admin@example.com)",
)

# Flask
SECRET_KEY = os.environ.get("MAC_SECRET_KEY", "dev-only-not-for-production")
MAX_UPLOAD_BYTES = int(os.environ.get("MAC_MAX_UPLOAD_BYTES", str(5 * 1024 * 1024)))
ALLOWED_UPLOAD_EXT = {".csv"}

# --- Demo mode -------------------------------------------------------------
DEMO_MODE = not bool(SARVAM_API_KEY)


def status() -> dict:
    """Runtime status surfaced to the UI and the /api/health endpoint."""
    return {
        "demo_mode": DEMO_MODE,
        "sarvam_configured": bool(SARVAM_API_KEY),
        "sarvam_model": SARVAM_MODEL,
        "llm_provider": "Sarvam AI (sarvamai SDK)",
        "db_path": DB_PATH,
    }
