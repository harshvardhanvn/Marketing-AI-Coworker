"""
SQLite persistence for the Marketing AI Coworker.

A fresh connection is opened per operation (Flask's dev server is threaded,
and sqlite3 connections are not safe to share across threads). All writes go
through small, explicit helpers so the schema stays in one place.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS businesses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    industry    TEXT,
    website     TEXT,
    description TEXT,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS recommendations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER,
    agent       TEXT NOT NULL,
    title       TEXT NOT NULL,
    detail      TEXT,
    priority    TEXT DEFAULT 'medium',
    status      TEXT DEFAULT 'open',
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS snapshots (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id     INTEGER,
    name            TEXT NOT NULL,
    source_filename TEXT,
    metrics_json    TEXT NOT NULL,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS content_assets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER,
    asset_type  TEXT NOT NULL,
    topic       TEXT,
    body        TEXT NOT NULL,
    demo        INTEGER DEFAULT 0,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS analyses (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id   INTEGER,
    analysis_type TEXT NOT NULL,
    input_json    TEXT,
    result_json   TEXT NOT NULL,
    demo          INTEGER DEFAULT 0,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS experiments (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id    INTEGER,
    title          TEXT NOT NULL,
    hypothesis     TEXT,
    primary_metric TEXT,
    status         TEXT DEFAULT 'planned',
    created_at     TEXT NOT NULL
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def get_conn():
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with get_conn() as conn:
        conn.executescript(SCHEMA)
    seed_sample_business()


# --------------------------------------------------------------------------
# Businesses
# --------------------------------------------------------------------------
SAMPLE_BUSINESS = {
    "name": "GreenLeaf Organics",
    "industry": "D2C Organic Food & Wellness",
    "website": "https://example.com",
    "description": (
        "A direct-to-consumer Indian brand selling cold-pressed oils, organic "
        "millets, and wellness supplements. Primary channels: Google Ads, Meta "
        "Ads, and email. Target market: urban health-conscious households."
    ),
}


def seed_sample_business() -> int:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT id FROM businesses WHERE name = ?", (SAMPLE_BUSINESS["name"],)
        ).fetchone()
        if row:
            return row["id"]
        cur = conn.execute(
            "INSERT INTO businesses (name, industry, website, description, created_at)"
            " VALUES (?, ?, ?, ?, ?)",
            (
                SAMPLE_BUSINESS["name"],
                SAMPLE_BUSINESS["industry"],
                SAMPLE_BUSINESS["website"],
                SAMPLE_BUSINESS["description"],
                _now(),
            ),
        )
        return cur.lastrowid


def get_business(business_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
    with get_conn() as conn:
        if business_id:
            row = conn.execute("SELECT * FROM businesses WHERE id = ?", (business_id,)).fetchone()
        else:
            row = conn.execute("SELECT * FROM businesses ORDER BY id LIMIT 1").fetchone()
        return dict(row) if row else None


# --------------------------------------------------------------------------
# Generic helpers
# --------------------------------------------------------------------------
def _rows(cur) -> List[Dict[str, Any]]:
    return [dict(r) for r in cur.fetchall()]


# --------------------------------------------------------------------------
# Recommendations
# --------------------------------------------------------------------------
def add_recommendation(business_id, agent, title, detail, priority="medium", status="open") -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO recommendations (business_id, agent, title, detail, priority, status, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (business_id, agent, title, detail, priority, status, _now()),
        )
        return cur.lastrowid


def add_recommendations(business_id, items: Iterable[Dict[str, Any]]) -> List[int]:
    ids = []
    for it in items:
        ids.append(
            add_recommendation(
                business_id,
                it.get("agent", "system"),
                it.get("title", "Untitled"),
                it.get("detail", ""),
                it.get("priority", "medium"),
            )
        )
    return ids


def list_recommendations(business_id=None, status=None) -> List[Dict[str, Any]]:
    q = "SELECT * FROM recommendations"
    clauses, params = [], []
    if business_id:
        clauses.append("business_id = ?")
        params.append(business_id)
    if status:
        clauses.append("status = ?")
        params.append(status)
    if clauses:
        q += " WHERE " + " AND ".join(clauses)
    q += " ORDER BY CASE priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, id DESC"
    with get_conn() as conn:
        return _rows(conn.execute(q, params))


def update_recommendation_status(rec_id: int, status: str) -> bool:
    with get_conn() as conn:
        cur = conn.execute("UPDATE recommendations SET status = ? WHERE id = ?", (status, rec_id))
        return cur.rowcount > 0


# --------------------------------------------------------------------------
# Snapshots
# --------------------------------------------------------------------------
def add_snapshot(business_id, name, metrics: Dict[str, Any], source_filename=None) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO snapshots (business_id, name, source_filename, metrics_json, created_at)"
            " VALUES (?, ?, ?, ?, ?)",
            (business_id, name, source_filename, json.dumps(metrics), _now()),
        )
        return cur.lastrowid


def list_snapshots(business_id=None) -> List[Dict[str, Any]]:
    q = "SELECT id, business_id, name, source_filename, created_at, metrics_json FROM snapshots"
    params: List[Any] = []
    if business_id:
        q += " WHERE business_id = ?"
        params.append(business_id)
    q += " ORDER BY id DESC"
    with get_conn() as conn:
        rows = _rows(conn.execute(q, params))
    for r in rows:
        r["metrics"] = json.loads(r.pop("metrics_json"))
    return rows


def get_snapshot(snap_id: int) -> Optional[Dict[str, Any]]:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM snapshots WHERE id = ?", (snap_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["metrics"] = json.loads(d.pop("metrics_json"))
    return d


# --------------------------------------------------------------------------
# Content assets
# --------------------------------------------------------------------------
def add_content_asset(business_id, asset_type, topic, body, demo=False) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO content_assets (business_id, asset_type, topic, body, demo, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (business_id, asset_type, topic, body, 1 if demo else 0, _now()),
        )
        return cur.lastrowid


def list_content_assets(business_id=None) -> List[Dict[str, Any]]:
    q = "SELECT * FROM content_assets"
    params: List[Any] = []
    if business_id:
        q += " WHERE business_id = ?"
        params.append(business_id)
    q += " ORDER BY id DESC"
    with get_conn() as conn:
        return _rows(conn.execute(q, params))


# --------------------------------------------------------------------------
# Analyses (history)
# --------------------------------------------------------------------------
def add_analysis(business_id, analysis_type, result: Dict[str, Any], input_data=None, demo=False) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO analyses (business_id, analysis_type, input_json, result_json, demo, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (
                business_id,
                analysis_type,
                json.dumps(input_data or {}),
                json.dumps(result),
                1 if demo else 0,
                _now(),
            ),
        )
        return cur.lastrowid


def list_analyses(business_id=None, analysis_type=None, limit=50) -> List[Dict[str, Any]]:
    q = "SELECT * FROM analyses"
    clauses, params = [], []
    if business_id:
        clauses.append("business_id = ?")
        params.append(business_id)
    if analysis_type:
        clauses.append("analysis_type = ?")
        params.append(analysis_type)
    if clauses:
        q += " WHERE " + " AND ".join(clauses)
    q += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    with get_conn() as conn:
        rows = _rows(conn.execute(q, params))
    for r in rows:
        r["input"] = json.loads(r.pop("input_json") or "{}")
        r["result"] = json.loads(r.pop("result_json") or "{}")
    return rows


# --------------------------------------------------------------------------
# Experiments
# --------------------------------------------------------------------------
def add_experiment(business_id, title, hypothesis, primary_metric, status="planned") -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO experiments (business_id, title, hypothesis, primary_metric, status, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (business_id, title, hypothesis, primary_metric, status, _now()),
        )
        return cur.lastrowid


def list_experiments(business_id=None) -> List[Dict[str, Any]]:
    q = "SELECT * FROM experiments"
    params: List[Any] = []
    if business_id:
        q += " WHERE business_id = ?"
        params.append(business_id)
    q += " ORDER BY id DESC"
    with get_conn() as conn:
        return _rows(conn.execute(q, params))


def reset_db() -> None:
    """Test helper - drops everything and re-initialises."""
    with get_conn() as conn:
        for t in (
            "experiments", "analyses", "content_assets",
            "snapshots", "recommendations", "businesses",
        ):
            conn.execute(f"DROP TABLE IF EXISTS {t}")
    init_db()
