#!/usr/bin/env bash
# Convenience launcher: sets up a venv, installs deps, and runs the app.
set -e
cd "$(dirname "$0")"
[ -f .env ] || cp .env.example .env
python3 -m venv .venv 2>/dev/null || true
source .venv/bin/activate
pip install -q -r requirements.txt
exec python app.py
