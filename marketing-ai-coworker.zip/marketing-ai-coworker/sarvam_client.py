"""
Thin, well-behaved wrapper around the official `sarvamai` SDK.

Design goals
------------
* One place that talks to Sarvam, so every agent has identical error handling.
* Never fabricate a live call. If there is no API key (or the call fails), we
  return a `LLMResult` whose `.demo` flag is True and whose text is clearly
  labelled `[DEMO MODE]`.
* Structured result object instead of raising, so agents can degrade gracefully.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import List, Optional

import config

try:  # The SDK is a hard requirement, but never crash the whole app on import.
    from sarvamai import SarvamAI
    _SDK_IMPORT_ERROR: Optional[str] = None
except Exception as exc:  # pragma: no cover - environment dependent
    SarvamAI = None  # type: ignore
    _SDK_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"


@dataclass
class LLMResult:
    text: str
    demo: bool
    model: str
    provider: str = "Sarvam AI"
    error: Optional[str] = None
    latency_ms: int = 0

    def to_dict(self) -> dict:
        return {
            "text": self.text,
            "demo": self.demo,
            "model": self.model,
            "provider": self.provider,
            "error": self.error,
            "latency_ms": self.latency_ms,
        }


class SarvamClient:
    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = (api_key if api_key is not None else config.SARVAM_API_KEY).strip()
        self.model = model or config.SARVAM_MODEL
        self._client = None

    # -- capability checks ---------------------------------------------------
    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    def _ensure_client(self):
        if _SDK_IMPORT_ERROR is not None:
            raise RuntimeError(f"sarvamai SDK unavailable: {_SDK_IMPORT_ERROR}")
        if self._client is None:
            self._client = SarvamAI(api_subscription_key=self.api_key)
        return self._client

    # -- main entry point ----------------------------------------------------
    def chat(
        self,
        system: str,
        user: str,
        temperature: float = 0.3,
        max_tokens: int = 1500,
        demo_text: Optional[str] = None,
    ) -> LLMResult:
        """
        Run a single chat completion.

        `demo_text` lets an agent supply a sensible canned answer for demo
        mode. It is ALWAYS prefixed with a DEMO marker so nobody can mistake
        it for a live model response.
        """
        messages: List[dict] = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]

        if not self.configured:
            return LLMResult(
                text=_demo_wrap(demo_text),
                demo=True,
                model=self.model,
                error=None,
            )

        start = time.time()
        try:
            client = self._ensure_client()
            resp = client.chat.completions(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            text = _extract_text(resp)
            return LLMResult(
                text=text,
                demo=False,
                model=self.model,
                latency_ms=int((time.time() - start) * 1000),
            )
        except Exception as exc:  # network, auth, rate limit, bad request...
            return LLMResult(
                text=_demo_wrap(demo_text),
                demo=True,
                model=self.model,
                error=f"{type(exc).__name__}: {exc}",
                latency_ms=int((time.time() - start) * 1000),
            )

    # -- health --------------------------------------------------------------
    def health_check(self) -> dict:
        """Cheap probe used by /api/health. Never raises."""
        if not self.configured:
            return {
                "configured": False,
                "reachable": False,
                "mode": "demo",
                "detail": "SARVAM_API_KEY not set - running in demo mode.",
            }
        if _SDK_IMPORT_ERROR is not None:
            return {
                "configured": True,
                "reachable": False,
                "mode": "error",
                "detail": f"sarvamai SDK unavailable: {_SDK_IMPORT_ERROR}",
            }
        res = self.chat(
            system="You are a health probe.",
            user="Reply with the single word: OK",
            temperature=0.0,
            max_tokens=8,
        )
        return {
            "configured": True,
            "reachable": not res.demo and res.error is None,
            "mode": "live" if not res.demo else "error",
            "detail": res.error or "Live Sarvam API responded.",
            "latency_ms": res.latency_ms,
            "model": res.model,
        }


def _extract_text(resp) -> str:
    """Pull text out of the SDK response, tolerating minor shape differences."""
    try:
        return (resp.choices[0].message.content or "").strip()
    except Exception:
        pass
    try:  # dict-like fallback
        return (resp["choices"][0]["message"]["content"] or "").strip()
    except Exception:
        return str(resp)


def _demo_wrap(demo_text: Optional[str]) -> str:
    marker = "[DEMO MODE - generated without a live Sarvam API call]"
    body = demo_text.strip() if demo_text else "No canned demo text was supplied for this step."
    return f"{marker}\n\n{body}"


def get_client() -> SarvamClient:
    return SarvamClient()
