"""
Campaign CSV parsing and metric computation.

All maths is done here in plain Python/pandas - never delegated to the LLM.
The LLM is only ever asked to *interpret* numbers we computed ourselves.

Metric definitions (standard paid-media conventions):
    CTR              = clicks / impressions * 100
    CPC              = spend / clicks
    Conversion Rate  = conversions / clicks * 100
    CPA              = spend / conversions
    ROAS             = revenue / spend
Any divide-by-zero yields None (rendered as null / "n/a"), never a fake 0.
"""
from __future__ import annotations

import io
from typing import Any, Dict, List, Optional

import pandas as pd

REQUIRED_COLUMNS = ["campaign", "impressions", "clicks", "spend", "conversions", "revenue"]
NUMERIC_COLUMNS = ["impressions", "clicks", "spend", "conversions", "revenue"]

# Tolerant header aliases so real-world exports mostly "just work".
COLUMN_ALIASES = {
    "campaign": ["campaign", "campaign_name", "campaign name", "ad_set", "adset"],
    "impressions": ["impressions", "impr", "impressions_count"],
    "clicks": ["clicks", "link_clicks", "link clicks", "click"],
    "spend": ["spend", "cost", "amount_spent", "amount spent", "spend_inr"],
    "conversions": ["conversions", "conv", "purchases", "leads", "conversions_count"],
    "revenue": ["revenue", "sales", "conversion_value", "conversion value", "revenue_inr"],
}


class CSVValidationError(ValueError):
    pass


def _safe_div(numerator: Optional[float], denominator: Optional[float]) -> Optional[float]:
    try:
        if denominator in (None, 0) or numerator is None:
            return None
        return numerator / denominator
    except (TypeError, ZeroDivisionError):
        return None


def compute_row_metrics(row: Dict[str, Any]) -> Dict[str, Any]:
    impressions = row.get("impressions")
    clicks = row.get("clicks")
    spend = row.get("spend")
    conversions = row.get("conversions")
    revenue = row.get("revenue")

    ctr = _safe_div(clicks, impressions)
    cpc = _safe_div(spend, clicks)
    conv_rate = _safe_div(conversions, clicks)
    cpa = _safe_div(spend, conversions)
    roas = _safe_div(revenue, spend)

    return {
        "ctr_pct": round(ctr * 100, 4) if ctr is not None else None,
        "cpc": round(cpc, 4) if cpc is not None else None,
        "conversion_rate_pct": round(conv_rate * 100, 4) if conv_rate is not None else None,
        "cpa": round(cpa, 4) if cpa is not None else None,
        "roas": round(roas, 4) if roas is not None else None,
    }


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    lower = {c.strip().lower(): c for c in df.columns}
    rename: Dict[str, str] = {}
    for canonical, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in lower:
                rename[lower[alias]] = canonical
                break
    df = df.rename(columns=rename)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise CSVValidationError(
            "Missing required column(s): " + ", ".join(missing)
            + ". Required: " + ", ".join(REQUIRED_COLUMNS) + "."
        )
    return df


def parse_and_analyse(content: bytes | str) -> Dict[str, Any]:
    """Parse raw CSV bytes and return per-campaign rows plus a computed summary."""
    if isinstance(content, bytes):
        try:
            text = content.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = content.decode("latin-1")
    else:
        text = content

    if not text.strip():
        raise CSVValidationError("The uploaded file is empty.")

    try:
        df = pd.read_csv(io.StringIO(text))
    except Exception as exc:
        raise CSVValidationError(f"Could not parse CSV: {exc}") from exc

    if df.empty:
        raise CSVValidationError("The CSV has a header but no data rows.")

    df = _normalise_columns(df)

    # Coerce numeric columns, dropping any non-numeric junk to NaN then to 0.
    for col in NUMERIC_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if df[NUMERIC_COLUMNS].isna().all(axis=None):
        raise CSVValidationError("No numeric data found in the metric columns.")

    df = df.fillna({c: 0 for c in NUMERIC_COLUMNS})
    df["campaign"] = df["campaign"].astype(str)

    if (df[NUMERIC_COLUMNS] < 0).any(axis=None):
        raise CSVValidationError("Metric columns must not contain negative values.")

    rows: List[Dict[str, Any]] = []
    for _, r in df.iterrows():
        base = {c: float(r[c]) for c in NUMERIC_COLUMNS}
        base["campaign"] = r["campaign"]
        metrics = compute_row_metrics(base)
        rows.append({**base, **metrics})

    totals = {c: float(df[c].sum()) for c in NUMERIC_COLUMNS}
    summary = compute_row_metrics(totals)

    best_roas = max(
        (r for r in rows if r["roas"] is not None),
        key=lambda r: r["roas"],
        default=None,
    )
    worst_cpa = max(
        (r for r in rows if r["cpa"] is not None),
        key=lambda r: r["cpa"],
        default=None,
    )

    return {
        "row_count": len(rows),
        "columns": REQUIRED_COLUMNS,
        "rows": rows,
        "totals": totals,
        "summary": summary,
        "highlights": {
            "best_roas_campaign": best_roas["campaign"] if best_roas else None,
            "best_roas_value": best_roas["roas"] if best_roas else None,
            "worst_cpa_campaign": worst_cpa["campaign"] if worst_cpa else None,
            "worst_cpa_value": worst_cpa["cpa"] if worst_cpa else None,
        },
    }


def compare_snapshots(older: Dict[str, Any], newer: Dict[str, Any]) -> Dict[str, Any]:
    """Diff two snapshot metric summaries. Lower CPA/CPC is better; higher is better for the rest."""
    o = older.get("summary", {}) or {}
    n = newer.get("summary", {}) or {}

    higher_is_better = {"ctr_pct", "conversion_rate_pct", "roas"}
    lower_is_better = {"cpc", "cpa"}
    labels = {
        "ctr_pct": "CTR (%)",
        "cpc": "CPC",
        "conversion_rate_pct": "Conversion Rate (%)",
        "cpa": "CPA",
        "roas": "ROAS",
    }

    deltas = []
    for key, label in labels.items():
        ov, nv = o.get(key), n.get(key)
        if ov is None or nv is None:
            deltas.append({
                "metric": label, "key": key, "old": ov, "new": nv,
                "abs_change": None, "pct_change": None, "direction": "n/a",
            })
            continue
        abs_change = nv - ov
        pct_change = (abs_change / ov * 100) if ov else None
        if abs_change == 0:
            direction = "flat"
        elif key in higher_is_better:
            direction = "improved" if abs_change > 0 else "declined"
        else:
            direction = "improved" if abs_change < 0 else "declined"
        deltas.append({
            "metric": label, "key": key,
            "old": round(ov, 4), "new": round(nv, 4),
            "abs_change": round(abs_change, 4),
            "pct_change": round(pct_change, 2) if pct_change is not None else None,
            "direction": direction,
        })

    improved = [d["metric"] for d in deltas if d["direction"] == "improved"]
    declined = [d["metric"] for d in deltas if d["direction"] == "declined"]

    return {
        "deltas": deltas,
        "improved": improved,
        "declined": declined,
        "verdict": _verdict(len(improved), len(declined)),
    }


def _verdict(improved: int, declined: int) -> str:
    if improved > declined:
        return "Net improvement"
    if declined > improved:
        return "Net decline"
    return "Mixed / flat"
