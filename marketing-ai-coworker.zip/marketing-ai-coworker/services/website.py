"""
Website fetching and on-page SEO extraction.

Fetches a real public URL (no third-party marketing API required), parses it
with BeautifulSoup, and derives a set of on-page SEO findings. All findings
come from the actual HTML; nothing is invented.

A light SSRF guard blocks obvious private/internal targets.
"""
from __future__ import annotations

import ipaddress
import json
import socket
import time
from typing import Any, Dict, List
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

import config


class FetchError(Exception):
    pass


_BLOCKED_HOST_SUFFIXES = (".local", ".localhost", ".internal", ".localdomain")
_BLOCKED_HOST_NAMES = {"localhost", "metadata", "metadata.google.internal"}


def _is_public_host(host: str) -> bool:
    """
    SSRF guard.

    Strategy:
      1. If the host is an IP literal, check it directly.
      2. Otherwise try to resolve it and reject private/loopback/link-local IPs.
      3. If local DNS is unavailable (common behind an egress proxy that does
         its own resolution), fall back to hostname heuristics instead of
         hard-failing - otherwise *every* fetch breaks in proxy environments.
         The outbound proxy still enforces the real egress policy.
    """
    if not host:
        return False

    try:
        ip = ipaddress.ip_address(host)
        return not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved)
    except ValueError:
        pass  # not an IP literal - it's a hostname

    lowered = host.lower()
    if lowered in _BLOCKED_HOST_NAMES or lowered.endswith(_BLOCKED_HOST_SUFFIXES):
        return False

    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        # Cannot resolve locally; defer to the network layer's own controls.
        return True

    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError:
            continue
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return False
    return True


def normalise_url(url: str) -> str:
    url = (url or "").strip()
    if not url:
        raise FetchError("No URL supplied.")
    if not urlparse(url).scheme:
        url = "https://" + url
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise FetchError("Only http/https URLs are supported.")
    if not parsed.netloc:
        raise FetchError("The URL does not contain a valid host.")
    return url


def fetch_page(url: str) -> Dict[str, Any]:
    url = normalise_url(url)
    host = urlparse(url).hostname
    if not _is_public_host(host):
        raise FetchError("Refusing to fetch a private/internal address.")

    start = time.time()
    try:
        resp = requests.get(
            url,
            timeout=config.HTTP_TIMEOUT,
            headers={"User-Agent": config.USER_AGENT, "Accept": "text/html,*/*"},
            allow_redirects=True,
            stream=True,
        )
    except requests.RequestException as exc:
        raise FetchError(f"Request failed: {exc}") from exc

    raw = resp.raw.read(config.HTTP_MAX_BYTES + 1, decode_content=True)
    truncated = len(raw) > config.HTTP_MAX_BYTES
    raw = raw[: config.HTTP_MAX_BYTES]
    elapsed_ms = int((time.time() - start) * 1000)

    if resp.status_code >= 400:
        raise FetchError(f"Server returned HTTP {resp.status_code}.")

    ctype = resp.headers.get("Content-Type", "")
    if "html" not in ctype.lower() and "xml" not in ctype.lower():
        raise FetchError(f"URL did not return HTML (Content-Type: {ctype or 'unknown'}).")

    html = raw.decode(resp.encoding or "utf-8", errors="replace")
    return {
        "url": url,
        "final_url": resp.url,
        "status_code": resp.status_code,
        "content_type": ctype,
        "bytes": len(raw),
        "truncated": truncated,
        "elapsed_ms": elapsed_ms,
        "html": html,
    }


def _meta(soup: BeautifulSoup, name: str) -> str | None:
    tag = soup.find("meta", attrs={"name": name}) or soup.find("meta", attrs={"property": name})
    if tag and tag.get("content"):
        return tag["content"].strip()
    return None


def analyse_html(page: Dict[str, Any]) -> Dict[str, Any]:
    soup = BeautifulSoup(page["html"], "html.parser")

    title_tag = soup.find("title")
    title = title_tag.get_text(strip=True) if title_tag else ""

    meta_desc = _meta(soup, "description")
    meta_robots = _meta(soup, "robots")
    canonical_tag = soup.find("link", attrs={"rel": lambda v: v and "canonical" in v})
    canonical = canonical_tag.get("href") if canonical_tag else None
    viewport = _meta(soup, "viewport")
    og_title = _meta(soup, "og:title")
    og_image = _meta(soup, "og:image")
    lang = soup.html.get("lang") if soup.html else None

    h1s = [h.get_text(strip=True) for h in soup.find_all("h1")]
    h2s = [h.get_text(strip=True) for h in soup.find_all("h2")]

    images = soup.find_all("img")
    images_missing_alt = [img for img in images if not (img.get("alt") or "").strip()]

    json_ld = soup.find_all("script", attrs={"type": "application/ld+json"})
    structured_data_types: List[str] = []
    for block in json_ld:
        try:
            data = json.loads(block.string or "{}")
            for item in (data if isinstance(data, list) else [data]):
                if isinstance(item, dict) and item.get("@type"):
                    structured_data_types.append(str(item["@type"]))
        except Exception:
            structured_data_types.append("invalid-json-ld")

    # Links
    base = page["final_url"]
    internal, external = 0, 0
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.startswith(("#", "mailto:", "tel:", "javascript:")):
            continue
        absolute = urljoin(base, href)
        if urlparse(absolute).netloc == urlparse(base).netloc:
            internal += 1
        else:
            external += 1

    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    text = soup.get_text(separator=" ", strip=True)
    word_count = len(text.split())

    return {
        "title": title,
        "title_length": len(title),
        "meta_description": meta_desc,
        "meta_description_length": len(meta_desc) if meta_desc else 0,
        "meta_robots": meta_robots,
        "canonical": canonical,
        "viewport": viewport,
        "lang": lang,
        "h1_count": len(h1s),
        "h1_texts": h1s[:5],
        "h2_count": len(h2s),
        "h2_samples": h2s[:5],
        "images_total": len(images),
        "images_missing_alt": len(images_missing_alt),
        "internal_links": internal,
        "external_links": external,
        "word_count": word_count,
        "has_og_title": bool(og_title),
        "has_og_image": bool(og_image),
        "structured_data_types": structured_data_types,
        "is_https": page["final_url"].startswith("https://"),
        "load_ms": page["elapsed_ms"],
        "page_bytes": page["bytes"],
    }


def find_issues(facts: Dict[str, Any]) -> List[Dict[str, str]]:
    issues: List[Dict[str, str]] = []

    def add(severity, area, message, fix):
        issues.append({"severity": severity, "area": area, "issue": message, "fix": fix})

    if not facts["title"]:
        add("high", "Title", "Page has no <title> tag.", "Add a unique title of 50-60 characters.")
    elif not (10 <= facts["title_length"] <= 60):
        add("medium", "Title", f"Title is {facts['title_length']} chars (ideal 50-60).",
            "Rewrite the title to 50-60 characters, leading with the primary keyword.")
    else:
        add("ok", "Title", f"Title length looks good ({facts['title_length']} chars).", "-")

    if not facts["meta_description"]:
        add("high", "Meta Description", "No meta description found.",
            "Add a 120-155 character description with a clear value proposition and CTA.")
    elif not (70 <= facts["meta_description_length"] <= 160):
        add("medium", "Meta Description",
            f"Meta description is {facts['meta_description_length']} chars (ideal 120-155).",
            "Rewrite to 120-155 characters so it isn't truncated in search results.")
    else:
        add("ok", "Meta Description", "Meta description length looks good.", "-")

    if facts["h1_count"] == 0:
        add("high", "Headings", "No <h1> heading on the page.",
            "Add exactly one descriptive H1 containing the main keyword.")
    elif facts["h1_count"] > 1:
        add("medium", "Headings", f"{facts['h1_count']} H1 tags found (should be one).",
            "Keep a single H1 and demote the others to H2/H3.")
    else:
        add("ok", "Headings", "Exactly one H1 found.", "-")

    if facts["images_total"] and facts["images_missing_alt"]:
        pct = facts["images_missing_alt"] / facts["images_total"] * 100
        sev = "high" if pct > 30 else "medium"
        add(sev, "Images", f"{facts['images_missing_alt']} of {facts['images_total']} images lack alt text.",
            "Add descriptive alt attributes; helps accessibility and image search.")

    if not facts["viewport"]:
        add("high", "Mobile", "No viewport meta tag - page may not be mobile-friendly.",
            'Add <meta name="viewport" content="width=device-width, initial-scale=1">.')

    if not facts["canonical"]:
        add("medium", "Canonical", "No canonical URL declared.",
            "Add a rel=canonical link to prevent duplicate-content dilution.")

    if not facts["is_https"]:
        add("high", "Security", "Page is not served over HTTPS.", "Install TLS and redirect HTTP to HTTPS.")

    if facts["word_count"] < 300:
        add("medium", "Content", f"Thin content ({facts['word_count']} words).",
            "Expand to 600+ words covering the topic and related queries.")

    if not facts["structured_data_types"]:
        add("low", "Structured Data", "No JSON-LD structured data found.",
            "Add Schema.org markup (Organization, Product, FAQ) to earn rich results.")

    if not (facts["has_og_title"] and facts["has_og_image"]):
        add("low", "Social", "Open Graph tags are incomplete.",
            "Add og:title, og:description and og:image for better social sharing.")

    return issues


def analyse_url(url: str) -> Dict[str, Any]:
    page = fetch_page(url)
    facts = analyse_html(page)
    issues = find_issues(facts)
    score = _seo_score(issues)
    return {
        "url": page["url"],
        "final_url": page["final_url"],
        "status_code": page["status_code"],
        "fetch_ms": page["elapsed_ms"],
        "page_bytes": page["bytes"],
        "facts": facts,
        "issues": issues,
        "seo_score": score,
        "issue_counts": {
            "high": sum(1 for i in issues if i["severity"] == "high"),
            "medium": sum(1 for i in issues if i["severity"] == "medium"),
            "low": sum(1 for i in issues if i["severity"] == "low"),
            "ok": sum(1 for i in issues if i["severity"] == "ok"),
        },
    }


def _seo_score(issues: List[Dict[str, str]]) -> int:
    penalty = {"high": 15, "medium": 8, "low": 3, "ok": 0}
    score = 100 - sum(penalty.get(i["severity"], 0) for i in issues)
    return max(0, min(100, score))
