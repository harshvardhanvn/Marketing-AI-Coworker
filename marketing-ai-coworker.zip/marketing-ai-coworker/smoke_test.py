"""End-to-end smoke test: start the real server, hit it over HTTP, verify."""
import json
import os
import threading
import time

os.environ.setdefault("MAC_DB_PATH", "/scratch/work/marketing-ai-coworker/data/smoke.db")
os.environ.pop("SARVAM_API_KEY", None)  # demo mode (no key available in sandbox)

import requests
from werkzeug.serving import make_server

import app as app_module


def main():
    server = make_server("127.0.0.1", 5055, app_module.app, threaded=True)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    base = "http://127.0.0.1:5055"
    results = {}

    def call(name, method, path, **kw):
        try:
            r = requests.request(method, base + path, timeout=60, **kw)
            results[name] = {"status": r.status_code}
            return r
        except Exception as exc:
            results[name] = {"status": "ERROR", "error": str(exc)}
            return None

    time.sleep(0.6)

    # 1. page + health
    r = call("index", "GET", "/")
    results["index"]["is_html"] = bool(r) and b"Marketing AI Coworker" in r.content
    r = call("health", "GET", "/api/health")
    if r is not None and r.ok:
        results["health"]["demo_mode"] = r.json()["config"]["demo_mode"]
        results["health"]["sarvam_mode"] = r.json()["sarvam"]["mode"]

    # 2. campaign (sample) - persistence + snapshot
    r = call("campaign_sample", "POST", "/api/campaign/analyze", json={"use_sample": True, "snapshot_name": "smoke-1"})
    if r is not None and r.ok:
        results["campaign_sample"]["roas"] = r.json()["result"]["metrics"]["summary"]["roas"]
        results["campaign_sample"]["snapshot_id"] = r.json()["snapshot_id"]

    # 3. live website SEO extraction (real network call)
    r = call("seo_live", "POST", "/api/seo/analyze", json={"url": "https://example.com"})
    if r is not None and r.ok:
        j = r.json()["result"]
        results["seo_live"]["title"] = j["facts"]["title"][:60]
        results["seo_live"]["score"] = j["seo_score"]
        results["seo_live"]["issues"] = j["issue_counts"]
    elif r is not None:
        results["seo_live"]["body"] = r.text[:200]

    # 4. keywords + content
    r = call("keywords", "POST", "/api/keywords/research", json={"topic": "cold pressed coconut oil"})
    if r is not None and r.ok:
        results["keywords"]["clusters"] = len(r.json()["result"]["clusters"])
    r = call("content", "POST", "/api/content/generate", json={"asset_type": "ad_copy", "topic": "millet bars"})
    if r is not None and r.ok:
        results["content"]["asset_id"] = r.json()["asset_id"]

    # 5. manager orchestration
    r = call("manager", "POST", "/api/manager/run",
             json={"use_sample_csv": True, "topic": "organic millets", "generate_content": True})
    if r is not None and r.ok:
        j = r.json()["result"]
        results["manager"]["agents_ran"] = j["agents_ran"]
        results["manager"]["recs"] = len(j["recommendations"])
        results["manager"]["plan_len"] = len(j["growth_plan"])

    # 6. snapshot compare
    r = call("recommendations", "GET", "/api/recommendations")
    if r is not None and r.ok:
        results["recommendations"]["count"] = len(r.json()["recommendations"])

    r = call("snapshots", "GET", "/api/snapshots")
    if r is not None and r.ok:
        results["snapshots"]["count"] = len(r.json()["snapshots"])

    r = call("history", "GET", "/api/history")
    if r is not None and r.ok:
        results["history"]["count"] = len(r.json()["history"])

    r = call("export_recs", "GET", "/api/export/recommendations.csv")
    if r is not None:
        results["export_recs"]["bytes"] = len(r.content)

    server.shutdown()
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
