/* Marketing AI Coworker - dashboard logic (vanilla JS, no external deps) */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/* ---------- toast + helpers ---------- */
let toastTimer;
function toast(msg, isErr = false) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast show" + (isErr ? " err" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast"), 3200);
}
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const num = (v, d = 2) => (v === null || v === undefined ? "n/a" : Number(v).toFixed(d));
const tag = (demo) => demo
  ? '<span class="demo-tag">DEMO output</span>'
  : '<span class="live-tag">LIVE Sarvam</span>';

function loading(el, msg = "Working&hellip;") { el.innerHTML = `<div class="panel loading">${msg}</div>`; }
function showError(el, msg) { el.innerHTML = `<div class="error-box">${esc(msg)}</div>`; }

async function api(path, opts = {}) {
  const res = await fetch(path, opts);
  let data;
  try { data = await res.json(); } catch { data = { ok: false, error: `HTTP ${res.status}` }; }
  if (!res.ok || data.ok === false) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

/* ---------- simple horizontal bar chart ---------- */
function barChart(container, items, valueFmt = (v) => num(v)) {
  const max = Math.max(...items.map((i) => Math.abs(i.value) || 0), 1);
  container.innerHTML = items.map((i) => `
    <div class="bar-row">
      <div class="bar-label" title="${esc(i.label)}">${esc(i.label)}</div>
      <div class="bar-track"><div class="bar-fill" style="width:${(Math.abs(i.value || 0) / max) * 100}%"></div></div>
      <div class="bar-val">${esc(valueFmt(i.value))}</div>
    </div>`).join("");
}

/* ---------- navigation ---------- */
function showView(name) {
  $$(".view").forEach((v) => v.classList.toggle("active", v.id === "view-" + name));
  $$(".nav-item").forEach((n) => n.classList.toggle("active", n.dataset.view === name));
  const loaders = {
    overview: loadOverview, recommendations: loadRecs, snapshots: loadSnapshots,
    experiments: loadExperiments, history: loadHistory, content: loadContentList,
  };
  if (loaders[name]) loaders[name]();
}
$$(".nav-item").forEach((n) => n.addEventListener("click", () => showView(n.dataset.view)));

/* ---------- overview + health ---------- */
async function loadOverview() {
  try {
    const h = await api("/api/health");
    $("#statRecs").textContent = h.counts.recommendations;
    $("#statSnaps").textContent = h.counts.snapshots;
    $("#statContent").textContent = h.counts.content_assets;
    const s = h.sarvam;
    $("#healthPill").textContent = s.reachable ? `Sarvam: live (${s.model})`
      : (s.configured ? "Sarvam: error" : "Sarvam: demo mode");
    $("#healthBox").innerHTML = `
      <div class="kv">
        <div class="item"><b>${esc(s.mode)}</b><span>LLM mode</span></div>
        <div class="item"><b>${esc(s.model || "-")}</b><span>Model</span></div>
        <div class="item"><b>${s.configured ? "yes" : "no"}</b><span>API key set</span></div>
        <div class="item"><b>${h.counts.analyses}</b><span>Analyses stored</span></div>
      </div>
      <p class="muted">${esc(s.detail)}</p>`;
  } catch (e) { $("#healthBox").innerHTML = `<span class="muted">Health check failed: ${esc(e.message)}</span>`; }

  try {
    const b = await api("/api/business");
    const biz = b.business || {};
    $("#businessBox").innerHTML = `<b>${esc(biz.name)}</b> &middot; <span class="muted">${esc(biz.industry)}</span><p class="muted">${esc(biz.description)}</p>`;
  } catch { /* non-fatal */ }
}

/* ---------- SEO ---------- */
$("#seoForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const url = e.target.url.value.trim();
  const out = $("#seoResult");
  loading(out, "Fetching page and analysing&hellip;");
  try {
    const { result: r } = await api("/api/seo/analyze", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });
    renderSeo(out, r);
    toast("SEO analysis complete");
  } catch (err) { showError(out, err.message); toast(err.message, true); }
});
document.querySelector("[data-fill-url]").addEventListener("click", () => {
  $("#seoForm").url.value = "https://www.python.org";
});

function renderSeo(out, r) {
  const f = r.facts;
  const rows = r.issues.map((i) => `<tr>
      <td><span class="pill-sev sev-${esc(i.severity)}">${esc(i.severity)}</span></td>
      <td>${esc(i.area)}</td><td>${esc(i.issue)}</td><td class="muted">${esc(i.fix)}</td></tr>`).join("");
  out.innerHTML = `
    <div class="panel">
      <h3>${esc(r.url)} &nbsp; <span class="chip">SEO score ${r.seo_score}/100</span> ${tag(r.llm.demo)}</h3>
      <div class="kv">
        <div class="item"><b>${f.title_length}</b><span>Title length</span></div>
        <div class="item"><b>${f.word_count}</b><span>Words</span></div>
        <div class="item"><b>${f.h1_count}</b><span>H1 tags</span></div>
        <div class="item"><b>${f.images_missing_alt}/${f.images_total}</b><span>Images missing alt</span></div>
        <div class="item"><b>${f.load_ms} ms</b><span>Fetch time</span></div>
        <div class="item"><b>${r.issue_counts.high}</b><span>High-severity issues</span></div>
      </div>
      <h3 style="margin-top:1rem">On-page findings</h3>
      <table><thead><tr><th>Severity</th><th>Area</th><th>Issue</th><th>Fix</th></tr></thead><tbody>${rows}</tbody></table>
      <h3 style="margin-top:1rem">Agent commentary</h3>
      <div class="llm-box">${esc(r.llm.text)}</div>
    </div>`;
}

/* ---------- Campaign ---------- */
$("#campaignForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const file = $("#csvFile").files[0];
  if (!file) { toast("Choose a CSV file, or click 'Analyse sample dataset'.", true); return; }
  const fd = new FormData();
  fd.append("file", file);
  fd.append("snapshot_name", $("#snapName").value || file.name);
  await runCampaign(fd);
});
$("#useSampleBtn").addEventListener("click", async () => {
  const fd = new FormData();
  fd.append("snapshot_name", "Sample run " + new Date().toLocaleTimeString());
  await runCampaign(fd, true);
});

async function runCampaign(fd, sample = false) {
  const out = $("#campaignResult");
  loading(out, "Computing metrics&hellip;");
  try {
    const data = sample
      ? await api("/api/campaign/analyze", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ use_sample: true, snapshot_name: "Sample run " + new Date().toLocaleTimeString() }),
        })
      : await api("/api/campaign/analyze", { method: "POST", body: fd });
    renderCampaign(out, data.result, data.snapshot_id);
    toast("Campaign analysis complete (snapshot #" + data.snapshot_id + ")");
  } catch (err) { showError(out, err.message); toast(err.message, true); }
}

function renderCampaign(out, r, snapId) {
  const m = r.metrics, s = m.summary;
  const head = `<div class="kv">
      <div class="item"><b>${num(s.ctr_pct)}%</b><span>CTR</span></div>
      <div class="item"><b>${num(s.cpc)}</b><span>CPC</span></div>
      <div class="item"><b>${num(s.conversion_rate_pct)}%</b><span>Conv. rate</span></div>
      <div class="item"><b>${num(s.cpa)}</b><span>CPA</span></div>
      <div class="item"><b>${num(s.roas)}x</b><span>ROAS</span></div>
      <div class="item"><b>${m.row_count}</b><span>Campaigns</span></div>
    </div>`;
  const rows = m.rows.map((row) => `<tr>
      <td>${esc(row.campaign)}</td><td>${row.impressions}</td><td>${row.clicks}</td>
      <td>${num(row.spend)}</td><td>${row.conversions}</td><td>${num(row.revenue)}</td>
      <td>${num(row.ctr_pct)}%</td><td>${num(row.cpc)}</td><td>${num(row.conversion_rate_pct)}%</td>
      <td>${num(row.cpa)}</td><td>${num(row.roas)}x</td></tr>`).join("");
  out.innerHTML = `
    <div class="panel">
      <h3>Computed metrics ${tag(r.llm.demo)} <span class="chip">snapshot #${snapId}</span>
        <a class="chip" href="/api/export/snapshots/${snapId}.csv">export CSV</a></h3>
      ${head}
      <p class="muted">Best ROAS: <b>${esc(m.highlights.best_roas_campaign)}</b> (${num(m.highlights.best_roas_value)}x) &middot;
         Worst CPA: <b>${esc(m.highlights.worst_cpa_campaign)}</b> (${num(m.highlights.worst_cpa_value)})</p>
      <h3 style="margin-top:1rem">ROAS by campaign</h3>
      <div id="roasChart"></div>
      <h3 style="margin-top:1rem">Per-campaign detail</h3>
      <table><thead><tr><th>Campaign</th><th>Impr.</th><th>Clicks</th><th>Spend</th><th>Conv.</th><th>Revenue</th><th>CTR</th><th>CPC</th><th>CVR</th><th>CPA</th><th>ROAS</th></tr></thead><tbody>${rows}</tbody></table>
      <h3 style="margin-top:1rem">Agent interpretation</h3>
      <div class="llm-box">${esc(r.llm.text)}</div>
    </div>`;
  barChart($("#roasChart"), m.rows.map((row) => ({ label: row.campaign, value: row.roas || 0 })), (v) => num(v) + "x");
}

/* ---------- Keywords ---------- */
$("#keywordsForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const topic = e.target.topic.value.trim();
  const out = $("#keywordsResult");
  loading(out, "Generating clusters&hellip;");
  try {
    const { result: r } = await api("/api/keywords/research", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ topic }),
    });
    const clusters = r.clusters.map((c) => `
      <div class="panel">
        <h3>${esc(c.intent)} ${tag(r.llm.demo)}</h3>
        <div>${c.keywords.map((k) => `<span class="chip">${esc(k)}</span>`).join("")}</div>
        <p class="muted" style="margin-top:.5rem"><b>Content opportunity:</b> ${esc(c.content_opportunity)}</p>
      </div>`).join("");
    out.innerHTML = `<div class="panel"><h3>Keyword clusters for "${esc(r.topic)}"</h3>
      <p class="muted">${esc(r.note)}</p></div>${clusters}
      <div class="panel"><h3>Agent commentary</h3><div class="llm-box">${esc(r.llm.text)}</div></div>`;
    toast("Keyword research complete");
  } catch (err) { showError(out, err.message); toast(err.message, true); }
});

/* ---------- Content ---------- */
$("#contentForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = {
    asset_type: $("#assetType").value,
    topic: e.target.topic.value.trim(),
    tone: e.target.tone.value.trim(),
  };
  const out = $("#contentResult");
  loading(out, "Writing copy&hellip;");
  try {
    const { result: r } = await api("/api/content/generate", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    out.innerHTML = `<div class="panel"><h3>${esc(r.asset_type)} &middot; ${esc(r.topic)} ${tag(r.llm.demo)}</h3>
      <p class="muted">Editable draft - copy and adapt as needed.</p>
      <textarea id="contentEdit">${esc(r.body)}</textarea>
      <div class="form-row" style="margin-top:.6rem"><button class="btn ghost" id="copyContent">Copy to clipboard</button></div>
    </div>`;
    $("#copyContent").addEventListener("click", () => {
      navigator.clipboard.writeText($("#contentEdit").value).then(() => toast("Copied"));
    });
    loadContentList();
    toast("Content generated and saved");
  } catch (err) { showError(out, err.message); toast(err.message, true); }
});

async function loadContentList() {
  const el = $("#contentList");
  if (!el) return;
  try {
    const { assets } = await api("/api/content");
    if (!assets.length) { el.innerHTML = '<span class="muted">No content assets yet.</span>'; return; }
    el.innerHTML = assets.map((a) => `<div class="kv"><div class="item" style="grid-column:1/-1">
      <b>${esc(a.asset_type)} &middot; ${esc(a.topic)}</b>
      <span>${esc(a.created_at)} ${a.demo ? "&middot; DEMO" : "&middot; LIVE"}</span>
      <div class="llm-box" style="margin-top:.4rem">${esc(a.body.slice(0, 400))}${a.body.length > 400 ? "&hellip;" : ""}</div>
    </div></div>`).join("");
  } catch { el.innerHTML = ""; }
}

/* ---------- Manager ---------- */
$("#managerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = {
    url: $("#mgrUrl").value.trim() || null,
    topic: $("#mgrTopic").value.trim() || null,
    use_sample_csv: $("#mgrSample").checked,
    generate_content: $("#mgrContent").checked,
  };
  const out = $("#managerResult");
  loading(out, "Orchestrating agents&hellip; this can take a few seconds.");
  try {
    const { result: r } = await api("/api/manager/run", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    const findings = Object.keys(r.findings).map((k) => `<span class="chip">${esc(k)}</span>`).join("");
    const failed = r.agents_failed.length
      ? `<p class="muted">Failed agents: ${r.agents_failed.map((f) => esc(f.agent + " (" + f.error + ")")).join(", ")}</p>` : "";
    const recs = r.recommendations.map((rec) => `<tr>
        <td><span class="pill-sev pri-${esc(rec.priority)}">${esc(rec.priority)}</span></td>
        <td>${esc(rec.agent)}</td><td>${esc(rec.title)}</td><td class="muted">${esc(rec.detail)}</td></tr>`).join("");
    out.innerHTML = `<div class="panel">
      <h3>Prioritised growth plan ${tag(r.demo)}</h3>
      <p class="muted">Agents run: ${r.agents_ran.map(esc).join(", ")} &nbsp; | &nbsp; Findings: ${findings}</p>
      ${failed}
      <div class="llm-box">${esc(r.growth_plan)}</div>
      <h3 style="margin-top:1rem">Combined recommendations (${r.recommendations.length})</h3>
      <table><thead><tr><th>Priority</th><th>Agent</th><th>Action</th><th>Detail</th></tr></thead><tbody>${recs}</tbody></table>
    </div>`;
    toast("Growth plan generated");
  } catch (err) { showError(out, err.message); toast(err.message, true); }
});

/* ---------- Recommendations ---------- */
async function loadRecs() {
  const el = $("#recsList");
  loading(el, "Loading recommendations&hellip;");
  try {
    const { recommendations } = await api("/api/recommendations");
    if (!recommendations.length) { el.innerHTML = '<div class="panel muted">No recommendations yet. Run an agent to generate some.</div>'; return; }
    const rows = recommendations.map((r) => `<tr>
        <td><span class="pill-sev pri-${esc(r.priority)}">${esc(r.priority)}</span></td>
        <td>${esc(r.agent)}</td><td>${esc(r.title)}</td><td class="muted">${esc(r.detail)}</td>
        <td><select data-rec="${r.id}">
          ${["open", "in_progress", "done", "dismissed"].map((s) => `<option value="${s}" ${r.status === s ? "selected" : ""}>${s}</option>`).join("")}
        </select></td></tr>`).join("");
    el.innerHTML = `<div class="panel"><table><thead><tr><th>Priority</th><th>Agent</th><th>Title</th><th>Detail</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table></div>`;
    $$("[data-rec]").forEach((sel) => sel.addEventListener("change", async () => {
      try {
        await api(`/api/recommendations/${sel.dataset.rec}`, {
          method: "PATCH", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: sel.value }),
        });
        toast("Status updated");
      } catch (e) { toast(e.message, true); }
    }));
  } catch (e) { showError(el, e.message); }
}
$("#refreshRecs").addEventListener("click", loadRecs);

/* ---------- Snapshots ---------- */
async function loadSnapshots() {
  try {
    const { snapshots } = await api("/api/snapshots");
    const opts = snapshots.map((s) => `<option value="${s.id}">#${s.id} ${esc(s.name)} (${esc(s.created_at)})</option>`).join("");
    $("#olderSnap").innerHTML = opts;
    $("#newerSnap").innerHTML = opts;
    if (snapshots.length >= 2) {
      $("#olderSnap").selectedIndex = 1;
      $("#newerSnap").selectedIndex = 0;
    }
  } catch (e) { toast(e.message, true); }
}
$("#compareBtn").addEventListener("click", async () => {
  const out = $("#compareResult");
  loading(out, "Comparing&hellip;");
  try {
    const data = await api("/api/snapshots/compare", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ older_id: $("#olderSnap").value, newer_id: $("#newerSnap").value }),
    });
    const c = data.comparison;
    const dirClass = (d) => d === "improved" ? "delta-up" : d === "declined" ? "delta-down" : "delta-flat";
    const arrow = (d) => d === "improved" ? "&uarr;" : d === "declined" ? "&darr;" : "&rarr;";
    const rows = c.deltas.map((d) => `<tr>
        <td>${esc(d.metric)}</td><td>${num(d.old, 4)}</td><td>${num(d.new, 4)}</td>
        <td class="${dirClass(d.direction)}">${arrow(d.direction)} ${d.abs_change === null ? "n/a" : num(d.abs_change, 4)}</td>
        <td class="${dirClass(d.direction)}">${d.pct_change === null ? "n/a" : num(d.pct_change) + "%"}</td>
        <td>${esc(d.direction)}</td></tr>`).join("");
    out.innerHTML = `<div class="panel">
      <h3>${esc(data.older.name)} &rarr; ${esc(data.newer.name)} <span class="chip">${esc(c.verdict)}</span></h3>
      <table><thead><tr><th>Metric</th><th>Older</th><th>Newer</th><th>Change</th><th>%</th><th>Direction</th></tr></thead><tbody>${rows}</tbody></table>
      <p class="muted">Improved: ${c.improved.join(", ") || "-"} &middot; Declined: ${c.declined.join(", ") || "-"}</p>
    </div>`;
    toast("Comparison ready");
  } catch (e) { showError(out, e.message); toast(e.message, true); }
});

/* ---------- Experiments ---------- */
$("#expForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    await api("/api/experiments", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: e.target.title.value, hypothesis: e.target.hypothesis.value, primary_metric: e.target.primary_metric.value }),
    });
    e.target.reset();
    toast("Experiment added");
    loadExperiments();
  } catch (err) { toast(err.message, true); }
});
async function loadExperiments() {
  const el = $("#expList");
  loading(el, "Loading experiments&hellip;");
  try {
    const { experiments } = await api("/api/experiments");
    if (!experiments.length) { el.innerHTML = '<div class="panel muted">No experiments planned yet.</div>'; return; }
    el.innerHTML = `<div class="panel"><table><thead><tr><th>Title</th><th>Metric</th><th>Hypothesis</th><th>Status</th></tr></thead><tbody>` +
      experiments.map((x) => `<tr><td>${esc(x.title)}</td><td>${esc(x.primary_metric)}</td><td class="muted">${esc(x.hypothesis)}</td><td>${esc(x.status)}</td></tr>`).join("") +
      `</tbody></table></div>`;
  } catch (e) { showError(el, e.message); }
}

/* ---------- History ---------- */
$("#refreshHistory").addEventListener("click", loadHistory);
async function loadHistory() {
  const el = $("#historyList");
  loading(el, "Loading history&hellip;");
  try {
    const { history } = await api("/api/history");
    if (!history.length) { el.innerHTML = '<div class="panel muted">No analyses yet.</div>'; return; }
    el.innerHTML = `<div class="panel"><table><thead><tr><th>#</th><th>Type</th><th>When</th><th>Source</th><th>Mode</th></tr></thead><tbody>` +
      history.map((h) => `<tr><td>${h.id}</td><td>${esc(h.analysis_type)}</td><td>${esc(h.created_at)}</td>
        <td class="muted">${esc(JSON.stringify(h.input))}</td>
        <td>${h.demo ? '<span class="demo-tag">DEMO</span>' : '<span class="live-tag">LIVE</span>'}</td></tr>`).join("") +
      `</tbody></table></div>`;
  } catch (e) { showError(el, e.message); }
}

/* ---------- init ---------- */
loadOverview();
