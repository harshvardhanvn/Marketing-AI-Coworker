"""Shared pytest fixtures. Uses a throwaway SQLite DB per test session."""
import os
import tempfile

import pytest

# Point the app at a temp DB BEFORE importing anything that reads config.
_TMP = tempfile.mkdtemp(prefix="mac_test_")
os.environ["MAC_DB_PATH"] = os.path.join(_TMP, "test.db")
os.environ.pop("SARVAM_API_KEY", None)  # force demo mode in tests


@pytest.fixture()
def client():
    import app as app_module
    app_module.db.reset_db()
    app_module.app.config.update(TESTING=True)
    with app_module.app.test_client() as c:
        yield c


@pytest.fixture()
def sample_csv_bytes():
    import config
    with open(config.SAMPLE_CSV_PATH, "rb") as fh:
        return fh.read()
