"""Agent-level tests. SEO detection is tested offline with crafted HTML."""
import pytest

from agents import campaign_analyst, content_creator, keyword_research, marketing_manager, seo_analyst
from services import website

SAMPLE_HTML = """
<html lang="en"><head>
  <title>Short</title>
</head><body>
  <h1>Welcome</h1><h1>Second H1</h1>
  <img src="a.png"><img src="b.png" alt="has alt">
  <p>tiny page</p>
  <a href="/internal">in</a><a href="https://external.example/x">out</a>
</body></html>
"""


def _fake_page(html=SAMPLE_HTML):
    return {
        "url": "https://example.com", "final_url": "https://example.com",
        "status_code": 200, "content_type": "text/html", "bytes": len(html),
        "truncated": False, "elapsed_ms": 12, "html": html,
    }


def test_analyse_html_detects_real_issues():
    facts = website.analyse_html(_fake_page())
    issues = website.find_issues(facts)
    areas = {i["area"] for i in issues}
    assert "Title" in areas                 # too-short title
    assert "Meta Description" in areas      # missing
    assert "Headings" in areas              # two H1s
    assert "Images" in areas                # one image missing alt
    assert "Mobile" in areas                # no viewport
    assert facts["h1_count"] == 2
    assert facts["images_total"] == 2
    assert facts["images_missing_alt"] == 1


def test_seo_agent_runs_offline(monkeypatch):
    monkeypatch.setattr(website, "fetch_page", lambda url: _fake_page())
    res = seo_analyst.run("https://example.com")
    assert res["agent"] == "SEO Analyst"
    assert 0 <= res["seo_score"] <= 100
    assert res["llm"]["demo"] is True
    assert len(res["recommendations"]) >= 1


def test_campaign_agent_computes_metrics(sample_csv_bytes):
    res = campaign_analyst.run(sample_csv_bytes)
    assert res["metrics"]["row_count"] == 6
    assert res["metrics"]["summary"]["roas"] == pytest.approx(5.6783, abs=1e-3)
    assert res["llm"]["demo"] is True
    assert len(res["recommendations"]) >= 1


def test_keyword_agent_has_no_fabricated_volume():
    res = keyword_research.run("cold pressed coconut oil")
    intents = {c["intent"] for c in res["clusters"]}
    assert intents == {"informational", "commercial", "transactional", "navigational"}
    blob = str(res).lower()
    for banned in ("search volume", "search_volume", "difficulty score", "cpc estimate"):
        assert banned not in blob
    assert res["llm"]["demo"] is True


def test_keyword_agent_requires_topic():
    with pytest.raises(ValueError):
        keyword_research.run("")


def test_content_agent_all_types():
    for atype in content_creator.ASSET_TYPES:
        res = content_creator.run(atype, "organic millet snacks")
        assert res["body"].strip()
        assert res["llm"]["demo"] is True


def test_content_agent_rejects_bad_type():
    with pytest.raises(ValueError):
        content_creator.run("not_a_type", "x")


def test_manager_orchestrates_csv_only(sample_csv_bytes):
    res = marketing_manager.run(csv_content=sample_csv_bytes, topic="organic millet snacks")
    assert "campaign" in res["findings"]
    assert "keywords" in res["findings"]
    assert res["agents_ran"]  # at least one agent
    assert res["recommendations"]
    assert res["growth_plan"].strip()
    assert res["demo"] is True


def test_manager_requires_inputs():
    with pytest.raises(ValueError):
        marketing_manager.run()


def test_ssrf_guard_blocks_private_and_local():
    assert website._is_public_host("localhost") is False
    assert website._is_public_host("127.0.0.1") is False
    assert website._is_public_host("10.0.0.5") is False
    assert website._is_public_host("169.254.169.254") is False
    assert website._is_public_host("foo.internal") is False
    # A public hostname must pass (resolution may be unavailable in proxy envs).
    assert website._is_public_host("example.com") is True
