"""End-to-end API tests via Flask's test client (no network required)."""
import io


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.get_json()
    assert body["ok"] is True
    assert body["status"] == "running"
    assert "counts" in body and "sarvam" in body


def test_index_page_renders(client):
    r = client.get("/")
    assert r.status_code == 200
    assert b"Marketing AI Coworker" in r.data


def test_business_seeded(client):
    r = client.get("/api/business")
    biz = r.get_json()["business"]
    assert biz["name"] == "GreenLeaf Organics"


def test_seo_requires_url(client):
    r = client.post("/api/seo/analyze", json={})
    assert r.status_code == 400
    assert r.get_json()["ok"] is False


def test_campaign_sample_creates_snapshot_and_recs(client):
    r = client.post("/api/campaign/analyze", json={"use_sample": True})
    assert r.status_code == 200
    body = r.get_json()
    assert body["ok"] is True
    assert body["snapshot_id"] >= 1
    assert body["result"]["metrics"]["summary"]["roas"] > 0

    recs = client.get("/api/recommendations").get_json()["recommendations"]
    assert len(recs) >= 1


def test_campaign_rejects_non_csv_upload(client):
    data = {"file": (io.BytesIO(b"hello"), "notes.txt")}
    r = client.post("/api/campaign/analyze", data=data, content_type="multipart/form-data")
    assert r.status_code == 422
    assert "Unsupported file type" in r.get_json()["error"]


def test_campaign_upload_valid_csv(client):
    csv = (b"campaign,impressions,clicks,spend,conversions,revenue\n"
           b"Test,1000,100,200,10,800\n")
    data = {"file": (io.BytesIO(csv), "camp.csv"), "snapshot_name": "upload-test"}
    r = client.post("/api/campaign/analyze", data=data, content_type="multipart/form-data")
    assert r.status_code == 200
    assert r.get_json()["result"]["metrics"]["row_count"] == 1


def test_campaign_rejects_bad_columns(client):
    csv = b"foo,bar\n1,2\n"
    data = {"file": (io.BytesIO(csv), "bad.csv")}
    r = client.post("/api/campaign/analyze", data=data, content_type="multipart/form-data")
    assert r.status_code == 422


def test_keywords_endpoint(client):
    r = client.post("/api/keywords/research", json={"topic": "organic millets"})
    assert r.status_code == 200
    assert len(r.get_json()["result"]["clusters"]) == 4


def test_keywords_requires_topic(client):
    r = client.post("/api/keywords/research", json={})
    assert r.status_code == 400


def test_content_generate_and_list(client):
    r = client.post("/api/content/generate", json={"asset_type": "ad_copy", "topic": "millet bars"})
    assert r.status_code == 200
    assert r.get_json()["asset_id"] >= 1
    lst = client.get("/api/content").get_json()["assets"]
    assert len(lst) == 1
    assert lst[0]["asset_type"] == "ad_copy"


def test_content_rejects_bad_type(client):
    r = client.post("/api/content/generate", json={"asset_type": "banner", "topic": "x"})
    assert r.status_code == 422


def test_manager_run_sample(client):
    r = client.post("/api/manager/run", json={"use_sample_csv": True, "topic": "organic millets"})
    assert r.status_code == 200
    body = r.get_json()["result"]
    assert "campaign" in body["findings"]
    assert body["growth_plan"].strip()


def test_manager_requires_inputs(client):
    r = client.post("/api/manager/run", json={})
    assert r.status_code == 400


def test_recommendation_status_update(client):
    client.post("/api/campaign/analyze", json={"use_sample": True})
    recs = client.get("/api/recommendations").get_json()["recommendations"]
    rid = recs[0]["id"]
    r = client.patch(f"/api/recommendations/{rid}", json={"status": "done"})
    assert r.status_code == 200
    r2 = client.patch(f"/api/recommendations/{rid}", json={"status": "bogus"})
    assert r2.status_code == 400
    r3 = client.patch("/api/recommendations/99999", json={"status": "done"})
    assert r3.status_code == 404


def test_snapshot_compare_flow(client):
    client.post("/api/campaign/analyze", json={"use_sample": True, "snapshot_name": "week1"})
    csv2 = open("sample_data/sample_campaign_v2.csv", "rb").read()
    data = {"file": (io.BytesIO(csv2), "week2.csv"), "snapshot_name": "week2"}
    client.post("/api/campaign/analyze", data=data, content_type="multipart/form-data")

    snaps = client.get("/api/snapshots").get_json()["snapshots"]
    assert len(snaps) == 2
    older, newer = snaps[1]["id"], snaps[0]["id"]
    r = client.post("/api/snapshots/compare", json={"older_id": older, "newer_id": newer})
    assert r.status_code == 200
    comp = r.get_json()["comparison"]
    assert comp["verdict"] in ("Net improvement", "Net decline", "Mixed / flat")
    assert len(comp["deltas"]) == 5

    r2 = client.post("/api/snapshots/compare", json={"older_id": 1})
    assert r2.status_code == 400


def test_experiments_flow(client):
    r = client.post("/api/experiments", json={"title": "Test CTA", "primary_metric": "CVR"})
    assert r.status_code == 200
    exps = client.get("/api/experiments").get_json()["experiments"]
    assert exps[0]["title"] == "Test CTA"
    r2 = client.post("/api/experiments", json={})
    assert r2.status_code == 400


def test_history_records_runs(client):
    client.post("/api/keywords/research", json={"topic": "millets"})
    hist = client.get("/api/history").get_json()["history"]
    assert any(h["analysis_type"] == "keywords" for h in hist)


def test_export_recommendations_csv(client):
    client.post("/api/campaign/analyze", json={"use_sample": True})
    r = client.get("/api/export/recommendations.csv")
    assert r.status_code == 200
    assert "text/csv" in r.headers["Content-Type"]
    assert b"priority" in r.data


def test_sample_csv_download(client):
    r = client.get("/api/sample/campaign.csv")
    assert r.status_code == 200
    assert b"campaign" in r.data


def test_unknown_endpoint_404(client):
    r = client.get("/api/does-not-exist")
    assert r.status_code == 404
    assert r.get_json()["ok"] is False
