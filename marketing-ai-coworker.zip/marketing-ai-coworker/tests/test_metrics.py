"""Metric math and CSV validation - the core 'mathematically correct' checks."""
import math

import pytest

from services import csv_metrics as cm


def test_row_metrics_known_values():
    row = {"impressions": 1000, "clicks": 50, "spend": 100, "conversions": 5, "revenue": 400}
    m = cm.compute_row_metrics(row)
    assert m["ctr_pct"] == pytest.approx(5.0)            # 50/1000*100
    assert m["cpc"] == pytest.approx(2.0)                # 100/50
    assert m["conversion_rate_pct"] == pytest.approx(10.0)  # 5/50*100
    assert m["cpa"] == pytest.approx(20.0)               # 100/5
    assert m["roas"] == pytest.approx(4.0)               # 400/100


def test_divide_by_zero_returns_none_not_fake_zero():
    m = cm.compute_row_metrics({"impressions": 0, "clicks": 0, "spend": 0,
                                "conversions": 0, "revenue": 0})
    assert m["ctr_pct"] is None
    assert m["cpc"] is None
    assert m["conversion_rate_pct"] is None
    assert m["cpa"] is None
    assert m["roas"] is None


def test_sample_dataset_totals(sample_csv_bytes):
    data = cm.parse_and_analyse(sample_csv_bytes)
    assert data["row_count"] == 6
    t = data["totals"]
    assert t["impressions"] == 566000
    assert t["clicks"] == 19890
    assert t["spend"] == 188400
    assert t["conversions"] == 1941
    assert t["revenue"] == 1069800

    s = data["summary"]
    # Independently recompute the aggregate metrics.
    assert s["ctr_pct"] == pytest.approx(round(19890 / 566000 * 100, 4))
    assert s["cpc"] == pytest.approx(round(188400 / 19890, 4))
    assert s["conversion_rate_pct"] == pytest.approx(round(1941 / 19890 * 100, 4))
    assert s["cpa"] == pytest.approx(round(188400 / 1941, 4))
    assert s["roas"] == pytest.approx(round(1069800 / 188400, 4))


def test_column_aliases_and_missing_columns():
    ok = "campaign_name,impr,link_clicks,cost,purchases,sales\nA,100,10,50,2,200\n"
    data = cm.parse_and_analyse(ok)
    assert data["rows"][0]["campaign"] == "A"
    assert data["rows"][0]["roas"] == pytest.approx(4.0)

    with pytest.raises(cm.CSVValidationError):
        cm.parse_and_analyse("campaign,impressions\nX,100\n")


def test_negative_values_rejected():
    bad = "campaign,impressions,clicks,spend,conversions,revenue\nX,-1,1,1,1,1\n"
    with pytest.raises(cm.CSVValidationError):
        cm.parse_and_analyse(bad)


def test_empty_and_header_only_rejected():
    with pytest.raises(cm.CSVValidationError):
        cm.parse_and_analyse(b"")
    with pytest.raises(cm.CSVValidationError):
        cm.parse_and_analyse("campaign,impressions,clicks,spend,conversions,revenue\n")


def test_compare_snapshots_direction():
    older = {"summary": {"ctr_pct": 3.0, "cpc": 10.0, "conversion_rate_pct": 5.0, "cpa": 100.0, "roas": 3.0}}
    newer = {"summary": {"ctr_pct": 4.0, "cpc": 8.0, "conversion_rate_pct": 6.0, "cpa": 80.0, "roas": 4.0}}
    c = cm.compare_snapshots(older, newer)
    by = {d["key"]: d for d in c["deltas"]}
    assert by["ctr_pct"]["direction"] == "improved"   # higher better
    assert by["cpc"]["direction"] == "improved"        # lower better
    assert by["roas"]["direction"] == "improved"
    assert c["verdict"] == "Net improvement"
