"""Sarvam client behaviour: demo-mode labelling and error handling."""
import sarvam_client
from sarvam_client import SarvamClient


def test_demo_mode_when_no_key():
    c = SarvamClient(api_key="")
    assert c.configured is False
    res = c.chat(system="s", user="u", demo_text="canned answer")
    assert res.demo is True
    assert res.error is None
    assert res.text.startswith("[DEMO MODE")
    assert "canned answer" in res.text


def test_demo_mode_when_no_canned_text():
    c = SarvamClient(api_key="")
    res = c.chat(system="s", user="u")
    assert res.demo is True
    assert "DEMO MODE" in res.text


def test_health_check_unconfigured():
    c = SarvamClient(api_key="")
    h = c.health_check()
    assert h["configured"] is False
    assert h["reachable"] is False
    assert h["mode"] == "demo"


def test_live_call_failure_is_handled_not_raised(monkeypatch):
    """If the SDK call raises, we must degrade to a labelled demo result."""
    c = SarvamClient(api_key="fake-key-to-force-live-path")

    def boom(*a, **k):
        raise RuntimeError("simulated network failure")

    monkeypatch.setattr(c, "_ensure_client", boom)
    res = c.chat(system="s", user="u", demo_text="fallback")
    assert res.demo is True
    assert res.error is not None
    assert "simulated network failure" in res.error


def test_get_client_uses_config_default():
    c = sarvam_client.get_client()
    assert isinstance(c, SarvamClient)
