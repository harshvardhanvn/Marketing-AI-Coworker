// Render the dashboard with a real headless browser and capture screenshots.
const { spawn } = require("child_process");
const http = require("http");
const puppeteer = require("/scratch/node_modules/puppeteer-core");

const PORT = 5056;
const BASE = `http://127.0.0.1:${PORT}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function ping() {
  return new Promise((resolve) => {
    const req = http.get(BASE + "/api/health", (res) => { res.resume(); resolve(res.statusCode === 200); });
    req.on("error", () => resolve(false));
    req.setTimeout(1500, () => { req.destroy(); resolve(false); });
  });
}

async function waitForServer(tries = 40) {
  for (let i = 0; i < tries; i++) {
    if (await ping()) return true;
    await sleep(500);
  }
  throw new Error("server did not start");
}

(async () => {
  const server = spawn("python3", ["app.py"], {
    cwd: "/scratch/work/marketing-ai-coworker",
    env: { ...process.env, PORT: String(PORT), MAC_DB_PATH: "/scratch/work/marketing-ai-coworker/data/ui.db" },
    stdio: "ignore",
  });
  try {
    await waitForServer();
    const browser = await puppeteer.launch({
      executablePath: "/usr/local/bin/chromium",
      headless: "new",
      args: ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
    });
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 900 });
    const errors = [];
    page.on("pageerror", (e) => errors.push(String(e)));
    page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });

    await page.goto(BASE + "/", { waitUntil: "networkidle0" });
    await sleep(800);
    await page.screenshot({ path: "/scratch/work/shot_overview.png" });

    // Campaign: run the sample dataset.
    await page.click('.nav-item[data-view="campaign"]');
    await page.click("#useSampleBtn");
    await sleep(1500);
    await page.screenshot({ path: "/scratch/work/shot_campaign.png", fullPage: true });

    // Manager run.
    await page.click('.nav-item[data-view="manager"]');
    await page.click("#managerForm button[type=submit]");
    await sleep(1500);
    await page.screenshot({ path: "/scratch/work/shot_manager.png", fullPage: true });

    // Recommendations.
    await page.click('.nav-item[data-view="recommendations"]');
    await sleep(1000);
    await page.screenshot({ path: "/scratch/work/shot_recommendations.png", fullPage: true });

    // Snapshots compare (two sample runs exist? ensure by running again)
    await page.click('.nav-item[data-view="campaign"]');
    await page.click("#useSampleBtn");
    await sleep(1200);
    await page.click('.nav-item[data-view="snapshots"]');
    await sleep(800);
    await page.click("#compareBtn");
    await sleep(1200);
    await page.screenshot({ path: "/scratch/work/shot_compare.png", fullPage: true });

    console.log("JS errors:", errors.length ? errors : "none");
    await browser.close();
  } finally {
    server.kill("SIGTERM");
  }
})();
